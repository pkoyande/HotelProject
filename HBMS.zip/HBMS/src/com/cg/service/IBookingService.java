package com.cg.service;

import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.Roomdetails;
import com.cg.bean.Users;
import com.cg.exception.BookingException;

public interface IBookingService {

	public boolean validateDetails(Users user)throws BookingException;
	public String addUser(Users user)throws BookingException;
	public boolean validateUser(String mobileNo,String password)throws BookingException;
	public List<Hotel> viewAllHotels()throws BookingException;
	public List<Roomdetails> getAllRooms(String hotelId)throws BookingException;
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)throws BookingException;
	public BookingDetails viewBookingDetails(String bookingId) throws BookingException;
}
