package com.cg.exception;

public class BookingException extends Exception{

	public BookingException(String msg) {
				System.out.println(msg);
	}
}
