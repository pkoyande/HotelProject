package com.capg.hba.ui;
//Working vala Project
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capg.hba.bean.User;
import com.capg.hba.service.AdminServiceImpl;
import com.capg.hba.service.IAdminService;
import com.capg.hba.service.IUserService;
import com.capg.hba.service.UserServiceImpl;

public class Client {

	public static Logger logger = Logger.getRootLogger();
	static Scanner sc = new Scanner(System.in);
	static IAdminService adminService = new AdminServiceImpl();
	static IUserService userService = new UserServiceImpl();
	static User user = null;
	static final int ATTEMPTS = 3;
	static UserClient userClient = new UserClient();
	static AdminClient adminClient = new AdminClient();

	public static void main(String[] args) {
		

		PropertyConfigurator.configure("resources//log4jGeneral.properties");
		logger.info("Application Started.");

		int option1 = 0;
		int option2 = 0;
		int option3 = 0;

		loop1: while (true) {

			printHeading("XYZ HOTEL BOOKING APP");
			System.out.println("1. Login");
			System.out.println("2. Register");
			System.out.println("3. Exit\n");
			
			option1 = inputOption();

			switch (option1) {

			case 1:

				loop2: while (true) {

					printHeading("LOGIN");
					System.out.println("1. User Login");
					System.out.println("2. Admin Login");
					System.out.println("3. Go to previous menu\n");

					option2 = inputOption();

					switch (option2) {

					case 1:

						user = userClient.userLogin();

						if (user == null) {
							logger.error("User login failed. Exceeded maximum number of attempts.");
							continue loop1;
						} else {
							logger.info("User " + user.getUserId()
									+ " logged in.");

							PropertyConfigurator
									.configure("resources//log4jUser.properties");

							logger.info("User " + user.getUserId()
									+ " logged in.");

							loop3: while (true) {

								printHeading("WELCOME " + user.getUserName());
								System.out.println("1. Search for hotels");
								System.out.println("2. Book hotel rooms");
								System.out.println("3. View booking status");
								System.out
										.println("4. Go back to previous menu\n");

								option3 = inputOption();

								switch (option3) {

								case 1:

									userClient.searchHotels();
									break;

								case 2:

									userClient.userBookRoom(user);
									break;

								case 3:

									userClient.viewBookingStatus();
									break;

								case 4:
									continue loop2;

								default:
									printError("Please enter a valid option!");

								}// end of switch
							}// end of while loop3
						}// end of else

					case 2:

						user = adminClient.adminLogIn();

						if (user == null) {
							logger.error("User login failed. Exceeded maximum number of attempts.");
							continue loop1;
						} else {
							logger.info("Admin " + user.getUserId()
									+ " logged in.");

							PropertyConfigurator
									.configure("resources//log4jAdmin.properties");

							logger.info("Admin " + user.getUserId()
									+ " logged in.");

							loop4: while (true) {
								Client.printHeading("WELCOME "
										+ user.getUserName());
								System.out
										.println("1. Perform Hotel Management");
								System.out
										.println("2. Perform Room Management");
								System.out.println("3. Generate Reports");
								System.out
										.println("4. Go back to previous menu\n");

								option2 = inputOption();

								switch (option2) {

								case 1:

									adminClient.performHotelManagement();
									break;

								case 2:// perform room management

									adminClient.performRoomManagement();
									break;

								case 3:// generate reports

									adminClient.generateReports();
									break;

								case 4:// previous menu

									continue loop2;

								default:
									printError("Please enter a valid option!");

								}// end of switch

							}// end of while loop4
						}// end of else

					case 3:
						continue loop1;

					default:
						printError("Please enter a valid ");

					}// end of second switch

				}// end of loop2

			case 2: // register

				userClient.register();
				break;

			case 3:

				System.exit(0);

			default:

				printError("Invalid option! Please select one of the given options.");

			}// end of first switch

		}// end of loop1
	}// end of main

	public static void printHeading(String heading) {
		printLineBreak();
		System.out.println("*** " + heading + " ***");
		printLineBreak();
	}// end of method
	
	public static void printError(String error) {
		System.out.println();
		System.out.println("ERROR: "+error);
		System.out.println();
	}// end of method
	
	public static void printInfo(String info) {
		System.out.println();
		System.out.println(info);
		System.out.println();
	}// end of method

	public static void printLineBreak() {
		System.out
				.println("_____________________________________________________________________________________");
	}// end of method

	public static int inputOption() {
		int option = 0;
		while (true) {
			try {
				System.out.println("Select an option:");
				option = sc.nextInt();
				break;
			} catch (InputMismatchException e) {
				sc.nextLine();
				printError("Please enter option in digits only!");
				continue;
			}// end of catch
		}// end of while loop
		return option;
	}// end of method

}// end of class

