package com.capg.hba.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Util {
	
	//------------------------ 1. Hotel Booking Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getRandomIntegerBetweenRange()
	 - Input Parameters	:	
	 - Return Type		:	int
	 - Throws			:  	ConnectionException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	17/9/2018
	 - Description		:	Generating Random integer in a given range
	 ********************************************************************************************************/

	public static int getRandomIntegerBetweenRange() {
		int min = 100;
		int max = 999;
		int x = (int) ((int) (Math.random() * ((max - min) + 1)) + min);
		return x;
	}// end of getRandomntegerBetweenRange

	public static List<String> citylist() {

		List<String> list = new ArrayList<String>();
		list.add("pune");
		list.add("mumbai");
		list.add("delhi");
		list.add("hyderabad");
		list.add("bangalore");
		list.add("chennai");
		list.add("indore");
		list.add("kolakata");
		list.add("bhopal");
		list.add("nagpur");
		return list;
	}// end of citylist method
	
	public static List<String> roomList(){
		List<String> list=new ArrayList<String>();
		list.add("Standard non A/C room");
		list.add("Standard A/C room");
		list.add("Executive A/C room");
		list.add("Deluxe A/C room");
		return list;
	}//end of roomList method
	
	public static void clear(){
		for (int i = 0; i < 50; ++i) System.out.println();
	}
}
