package com.capg.hba.service;

//import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.dao.BookingDAOImpl;
import com.capg.hba.dao.HotelDAOImpl;
import com.capg.hba.dao.IBookingDAO;
import com.capg.hba.dao.IHotelDAO;
import com.capg.hba.dao.IRoomDAO;
import com.capg.hba.dao.IUserDAO;
import com.capg.hba.dao.RoomDAOImpl;
import com.capg.hba.dao.UserDAOImpl;
import com.capg.hba.exceptions.ConnectionException;

public class UserServiceImpl implements IUserService {

	IUserDAO dao = new UserDAOImpl();
	IHotelDAO daoh = new HotelDAOImpl();
	IRoomDAO daor = new RoomDAOImpl();
	IBookingDAO daob = new BookingDAOImpl();

	@Override
	public String userRegistration(User user) throws ConnectionException {
		user.setRole("USER"); //Change here
		return dao.addUser(user);
	}

	@Override
	public User userSignIn(String userName, String password)
			throws ConnectionException {
		return dao.userSignIn(userName, password, "USER");

	}

	@Override
	public HashMap<Hotel, Integer> userSearchHotels(String city,
			String address, Double avgRate, int rating)
			throws ConnectionException {
		List<Hotel> hotel = daoh.userSearchHotels(city, address, avgRate,
				rating);
		HashMap<Hotel, Integer> avail_rooms = new<Hotel, Integer> HashMap();
		if (!hotel.isEmpty()) {
			for (Hotel h : hotel) {
				//Made change here
				List <Room> rooms = daor.userSearchRooms(h.getHotelId());
				if(rooms!=null){
					avail_rooms.put(h, rooms.size());
				}
				else{
					avail_rooms.put(h, 0);
				}
			}
		}
		return avail_rooms;
	}

	@Override
	public List<Room> userSearchRooms(String hotelId)
			throws ConnectionException {
		return daor.userSearchRooms(hotelId);

	}

	@Override
	public String userBookRoom(Booking booking) throws ConnectionException {
		boolean status = daor.getAvailabilityOfRoom(booking.getRoom()
				.getRoomId());
		boolean date = daob.checkBookingDates(booking.getBookedFrom(),booking.getBookedTo(),booking.getRoom());
		if(status && date)
		{
			return daob.userAddBooking(booking);
			
		}
		else
		{
			throw new ConnectionException("Room not available in the speecified dates!");
		}

	}

	@Override
	public Booking userBookingStatus(String bookingId) throws ConnectionException {
		return daob.getBooking(bookingId);
	}

	@Override
	public boolean validateUser(User user) {
		return (user != null);
	}

	@Override
	public boolean validateUserName(String userName) {

		return userName.matches("[a-zA-Z]{1,20}"); //Made change here
	}

	@Override
	public boolean validatePassword(String password) {
		return ((Pattern.compile("^[a-zA-Z0-9._%+-@]{6,7}$", Pattern.CASE_INSENSITIVE)).matcher(password)).matches();
	}
	@Override
	public boolean validateRole(String role) {
		return role.matches("user") || role.matches("admin");
	}

	@Override
	public boolean validatePhone(String phoneNo) {
		return phoneNo.matches("[0-9]{8,8}");
	}

	@Override
	public boolean validateMobile(String mobileNo) {
		return mobileNo.matches("[0-9]{10,10}");
	}

	@Override
	public boolean validateEmail(String email) {
		
		return ((Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE)).matcher(email)).matches();
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		return userAddress.length()<=25; //Change here
		//return userAddress.matches("[a-zA-Z]{25}");
	}

	@Override
	public Room getRoom(String roomId) throws ConnectionException {
		return daor.getRoom(roomId);
	}

	@Override
	public Hotel getHotel(String hotelId) throws ConnectionException {
		return daoh.getHotel(hotelId);
	}
	
	@Override
	public boolean validateNoOfAdults(int adults) {
		if(adults>10)
			return false;
		else
			return true;
	}

	@Override
	public boolean validateNoOfChildren(int children) {
		if(children>4)
			return false;
		else
			return true;
	}

	@Override
	public boolean validateDate(String date) {
		/*if(date.matches("(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)"))*/
		if(date.matches("((19|20)\\d\\d)/(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])"))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateBookingDates(Date bookingFrom, Date bookingTo) {
		DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");

		Date today = new Date();

		Date todayWithZeroTime;
		try {
			todayWithZeroTime = formatter.parse(formatter.format(today));
			if (bookingFrom.after(todayWithZeroTime)
					|| bookingFrom.equals(todayWithZeroTime)) {
				if (bookingTo.after(bookingFrom))
				{
					System.out.println("In true");
					return true;
				}
					else
					{
						System.out.println("In false");
					return false;
					}
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

}
