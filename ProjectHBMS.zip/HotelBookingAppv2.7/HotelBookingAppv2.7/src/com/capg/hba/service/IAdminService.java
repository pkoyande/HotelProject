package com.capg.hba.service;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;

public interface IAdminService {

	public User adminLogin(String userName,String password) throws ConnectionException; 
	public String adminAddHotel(Hotel hotel) throws ConnectionException;
	public boolean adminDeleteHotel(String hotelId) throws ConnectionException;
	public boolean adminModifyHotel(Hotel hotel) throws ConnectionException;
	public String adminAddRoom(Room room) throws ConnectionException;
	public boolean adminDeleteRoom(String roomId) throws ConnectionException;
	public boolean adminModifyRoom(Room room) throws ConnectionException;
	public List<Hotel> adminViewHotels() throws ConnectionException;       
	public List<Booking> adminViewBookingsForHotel(String hotelId) throws ConnectionException; 
	public HashMap<Booking, User> adminViewGuestList(String hotelId) throws ConnectionException; //kaam //a
	public List<Booking> adminViewBookingsForDate(Date date) throws ConnectionException;
	public boolean validateHotel(Hotel hotel); 
	public boolean validateCity(String city); 
	public boolean validateHotelName(String hotelName); 
	public boolean validateAddress(String hotelAddress); 
	public boolean validateDescription(String Description); 
	public boolean validateRate(double Rate); 
	public boolean validatePhoneNo(String phone); 
	public boolean validateFax(String fax); 
	public boolean validateEmail(String email); 
	
	public boolean validateRoom(Room room);
	public boolean validateRoomNo(String roomNo);
	public boolean validateRoomType(String roomType);
	public boolean validateRating(int x);
	public Hotel getHotel(String hotelId) throws ConnectionException;
	Room getRoom(String roomId) throws ConnectionException;
	
	
	
}                                                                                          
