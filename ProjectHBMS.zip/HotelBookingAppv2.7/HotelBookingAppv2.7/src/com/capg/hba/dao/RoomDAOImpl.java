package com.capg.hba.dao;

import com.capg.hba.ui.Client;
import com.capg.hba.util.DBConnection;
import com.capg.hba.util.Util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import oracle.sql.BLOB;

import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.exceptions.ConnectionException;

public class RoomDAOImpl implements IRoomDAO {

	
	// ------------------------ 1. Hotel Booking Application --------------------------
	/*******************************************************************************************************
	 * - Function Name : userSearchRooms(String hotelId) - Input Parameters :
	 * String hotelId - Return Type : List<Room> - Throws : ConnectionException
	 * - Author : CAPGEMINI - Creation Date : 19/9/2018 - Description : Search
	 * rooms having a particular hotelId
	 ********************************************************************************************************/

	@Override
	public List<Room> userSearchRooms(String hotelId)
			throws ConnectionException {

		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Room> rooms = null;
		Room room = null;
		int roomCount = 0;

		try {

			preparedStatement = connection
					.prepareStatement(QueryMapper.SEARCH_ROOMS);

			preparedStatement.setString(1, hotelId);

			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				
				

				rooms = new ArrayList<Room>();

				while (resultSet.next()) {

					room = new Room();

					room.setRoomId(resultSet.getString("ROOM_ID"));
					room.setHotel(new HotelDAOImpl().getHotel(resultSet
							.getString("HOTEL_ID")));
					room.setRoomNo(resultSet.getString("ROOM_NO"));
					room.setRoomType(resultSet.getString("ROOM_TYPE"));
					room.setPerNightRate(resultSet.getDouble("PER_NIGHT_RATE"));

					String available = resultSet.getString("AVAILABILITY");

					if (available.equals("Y")) {
						room.setAvailability(true);
					} else {
						room.setAvailability(false);
					}// end of else
					
					/*if(resultSet.getBlob(7)!=null){ //Made change here

					BLOB blob = (BLOB) resultSet.getBlob(7);
					InputStream is = blob.getBinaryStream();
					BufferedImage bufImg = ImageIO.read(is);

					room.setPhoto(bufImg);
					}*/
					
					/*if(resultSet.getString("PHOTO_PATH")!=null){
						room.setPhotoPath(resultSet.getString("PHOTO_PATH"));
						room.setPhoto(ImageIO.read(new File(resultSet.getString("PHOTO_PATH"))));
					}*/

					rooms.add(room);

					roomCount++;

				}// end of while
				

			}

		} catch (SQLException e) {

			Client.logger.error("Exception during search rooms\n"
					+ e.getMessage());
			throw new ConnectionException(
					"Technical problems occured. Refer log.");

		} catch (Exception e) {

			Client.logger.error("Exception during search rooms\n"
					+ e.getMessage());
			throw new ConnectionException("Image of room was invalid!");

		} finally {

			try {

				connection.close();
				preparedStatement.close();

			} catch (SQLException e) {

				Client.logger
						.error("Exception while closing databse connection\n"
								+ e.getMessage());
				throw new ConnectionException(
						"Error in closing database connection.");

			}

		}// end of catch

		if (roomCount > 0) { //made change here
			Client.logger.info("Successful room search occured.");
			return rooms;
		} else {
			Client.logger.info("No rooms were found for given constraint.");
			return null;
		}

	}// end of userSearchRooms

	// ------------------------ 1. Hotel Booking Application
	// --------------------------
	/*******************************************************************************************************
	 * - Function Name : adminAddRoom(Room room) - Input Parameters : Room room
	 * - Return Type : String - Throws : ConnectionException - Author :
	 * CAPGEMINI - Creation Date : 19/9/2018 - Description : Add a new room to
	 * room table
	 ********************************************************************************************************/

	@Override
	public String adminAddRoom(Room room) throws ConnectionException {

		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;
		ResultSet resultSet = null;
		String roomId = null;
		int id;
		String available;

		try {

			while (true) {

				id = Util.getRandomIntegerBetweenRange();
				roomId = "R" + id;

				preparedStatement1 = connection
						.prepareStatement(QueryMapper.RETRIEVE_ROOMID_QUERY);

				preparedStatement1.setString(1, roomId);

				resultSet = preparedStatement1.executeQuery();

				if (resultSet.next())
					continue;
				else
					break;

			}// end of while

			if (room.isAvailability())
				available = "Y";
			else
				available = "N";

			preparedStatement2 = connection
					.prepareStatement(QueryMapper.ADD_ROOM);

			preparedStatement2.setString(1, roomId);
			preparedStatement2.setString(2, room.getHotel().getHotelId());
			preparedStatement2.setString(3, room.getRoomNo());
			preparedStatement2.setString(4, room.getRoomType());
			preparedStatement2.setDouble(5, room.getPerNightRate());
			preparedStatement2.setString(6, available);

		
			/*String photoPath="roomImages//room"+roomId+".jpg";			//CHANGE THIS TO PUT PHOTOPATH IN DB
			ImageIO.write(room.getPhoto(), "jpg", new File(photoPath));
			preparedStatement2.setString(7, photoPath);*/
			
			boolean res = preparedStatement2.execute();

			if (res) {
				roomId = null;
				Client.logger.error("Room details insertion failed!");
				throw new ConnectionException("Room insertion failed!");
			} else {
				Client.logger.info("New room " + room.getRoomId()
						+ " added to database.");
			}

		} catch (SQLException e) {

			Client.logger.error("Exception during room insertion:\n"
					+ e.getMessage());
			throw new ConnectionException(
					"Technical problems occured! Refer log.");

		} catch (Exception e) {

			Client.logger.error("Exception during room insertion:\n"
					+ e.getMessage());
			throw new ConnectionException(
					"Technical problems occured! Refer log.");

		} finally {

			try {

				preparedStatement1.close();
				preparedStatement2.close();
				resultSet.close();
				connection.close();

			} catch (SQLException e) {

				Client.logger.error("Exception while closing db connection: "+e.getMessage());
				throw new ConnectionException(
						"Error in closing db connection.");

			}

		}// end of catch

		return roomId;

	}// End of adminAddRoom

	// ------------------------ 1. Hotel Booking Application
	// --------------------------
	/*******************************************************************************************************
	 * - Function Name : adminDeleteRoom(String roomId) - Input Parameters :
	 * String roomId - Return Type : boolean - Throws : ConnectionException -
	 * Author : CAPGEMINI - Creation Date : 19/9/2018 - Description : Delete a
	 * room from room table
	 ********************************************************************************************************/

	@Override
	public boolean adminDeleteRoom(String roomId) throws ConnectionException {

		boolean isDeleted = false;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;

		try {

			preparedStatement = connection
					.prepareStatement(QueryMapper.DELETE_ROOM);

			preparedStatement.setString(1, roomId);

			int res = preparedStatement.executeUpdate();

			if (res > 0) {
				isDeleted = true;
				Client.logger.info("Room successfully deleted with room Id : "+roomId);
			}// end of if

		} catch (SQLException e) {

			Client.logger.error("Exception while deleting room with room Id "+roomId+" :"+e.getMessage());
			throw new ConnectionException(
					"Room data could not be deleted from database!");

		} finally {

			try {

				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {

				Client.logger.error("Exception while closing db connection: "+e.getMessage());
				throw new ConnectionException(
						"Error in closing db connection.");

			}

		}// end of catch

		return isDeleted;

	}// end of adminDeleteRoom

	// ------------------------ 1. Hotel Booking Application
	// --------------------------
	/*******************************************************************************************************
	 * - Function Name : adminModifyRoom(Room room) - Input Parameters : Room
	 * room - Return Type : int - Throws : ConnectionException - Author :
	 * CAPGEMINI - Creation Date : 19/9/2018 - Description : Modify a room from
	 * room table
	 ********************************************************************************************************/

	@Override
	public boolean adminModifyRoom(Room room) throws ConnectionException {

		boolean result = false;
		int n = 0;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		String available = null;

		try {

			preparedStatement = connection
					.prepareStatement(QueryMapper.MODIFY_ROOM);

			preparedStatement.setString(1, room.getHotel().getHotelId());
			preparedStatement.setString(2, room.getRoomNo());
			preparedStatement.setString(3, room.getRoomType());
			preparedStatement.setDouble(4, room.getPerNightRate());

			if (room.isAvailability()) {
				available = "Y";
			} else {
				available = "N";
			}// end of else

			preparedStatement.setString(5, available);

			/*ByteArrayOutputStream baos = new ByteArrayOutputStream();

			try {

				ImageIO.write(room.getPhoto(), "jpg", baos);

			} catch (IOException e) {

				Client.logger.error("Exception while modfying room data for room Id "+room.getRoomId()+" :"+e.getMessage());
				throw new ConnectionException(
						"Room data could not be modified from database!");

			}// end of catch

			InputStream is = new ByteArrayInputStream(baos.toByteArray());*/

			preparedStatement.setString(6, room.getPhotoPath());
			preparedStatement.setString(7, room.getRoomId());

			n = preparedStatement.executeUpdate();

			if (n > 0) {
				result = true;
				Client.logger.info("Room data modified for room Id : "+room.getRoomId());
			}
			else{
				Client.logger.info("Room data not modified for room Id : "+room.getRoomId());
			}

		} catch (SQLException e) {

			Client.logger.error("Exception while modfying room data for room Id "+room.getRoomId()+" :"+e.getMessage());
			throw new ConnectionException(
					"Room data could not be modified from database!");

		} 

		return result;

	}// end of adminModifyRoom

	// ------------------------ 1. Hotel Booking Application
	// --------------------------
	/*******************************************************************************************************
	 * - Function Name : getRoom(String roomId) - Input Parameters : String
	 * roomId - Return Type : Room - Throws : ConnectionException - Author :
	 * CAPGEMINI - Creation Date : 19/9/2018 - Description : Get a room object
	 * corresponding to roomId
	 ********************************************************************************************************/
	@Override
	public Room getRoom(String roomId) throws ConnectionException {

		Room room = null;
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {

			preparedStatement = connection
					.prepareStatement(QueryMapper.GET_ROOM);
			preparedStatement.setString(1, roomId);

			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {

				room = new Room();

				room.setRoomId(resultSet.getString("ROOM_ID"));
				room.setHotel(new HotelDAOImpl().getHotel(resultSet
						.getString("HOTEL_ID")));
				room.setRoomNo(resultSet.getString("ROOM_NO"));
				room.setRoomType(resultSet.getString("ROOM_TYPE"));
				room.setPerNightRate(resultSet.getDouble("PER_NIGHT_RATE"));

				/*if(resultSet.getBinaryStream(7)!=null){
					InputStream in = resultSet.getBinaryStream(7);
					BufferedImage image = ImageIO.read(in);
					room.setPhoto(image);
				}*/

				String available = resultSet.getString("AVAILABILITY");

				if (available.equals("Y")) {
					room.setAvailability(true);
				} else {
					room.setAvailability(false);
				}// end of else
				
				/*if(resultSet.getString("PHOTO_PATH")!=null){							CHANGE THIS TO GET PHOTO PATH
					room.setPhotoPath(resultSet.getString("PHOTO_PATH"));
					BufferedImage bufferedImage = ImageIO.read(new File(
							resultSet.getString("PHOTO_PATH")));
					room.setPhoto(bufferedImage);
				}
*/
			}// end of if

			if (room != null) {
				Client.logger.info("Room details regarding room ID "
						+ room.getRoomId() + " found successfully.");
				return room;
			} else {
				Client.logger.info("No records found regarding room ID "
						+ roomId);
				return null;
			}

		} catch (SQLException e) {

			Client.logger.error("Exception occured while retrieving details for room Id "+roomId+" :"+e.getMessage());
			throw new ConnectionException(
					"Room data could not be retrieved from database!");

		} catch (Exception e) {

			Client.logger.error("Exception occured while retrieving details for room Id "+roomId+" :"+e.getMessage());
			throw new ConnectionException(
					"Room data could not be retrieved from database!");

		} finally {

			try {

				connection.close();
				preparedStatement.close();

			} catch (SQLException e) {

				Client.logger.error("Exception occured while closing db connection: "+e.getMessage());
				throw new ConnectionException(
						"Room data could not be modified from database!");

			}// end of catch

		}// end of catch

	}// end of getRoom

	@Override
	public Map<Hotel, Integer> userHotelRooms(List<Hotel> hotels) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean getAvailabilityOfRoom(String roomId) throws ConnectionException {
		
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.RETRIEVE_AVAILABILITY);
			preparedStatement.setString(1, roomId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				if(resultSet.getString(1).equals("Y"))
				{
					return true;
				}
				else
					return false;
			}
		}//end of try
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end of catch
		finally{
			
			try {
				
				connection.close();
				preparedStatement.close();
			}//end of try
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//end of catch
		}//end of finally
		return false;
		
	}

}// End of Class
