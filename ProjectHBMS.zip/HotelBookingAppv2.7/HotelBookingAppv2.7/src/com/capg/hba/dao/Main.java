package com.capg.hba.dao;

import static org.junit.Assert.assertNotNull;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import com.capg.hba.bean.Room;
import com.capg.hba.exceptions.ConnectionException;

public class Main {

	public static void main(String[] args) throws ConnectionException {
		RoomDAOImpl rdao = new RoomDAOImpl();
		Room room = rdao.getRoom("R463");
		System.out.println(room.getHotel().getHotelId());
		/*BufferedImage image = room.getPhoto();
		 JFrame editorFrame = new JFrame("Image Demo");
	        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	        ImageIcon imageIcon = new ImageIcon(image);
	        JLabel jLabel = new JLabel();
	        jLabel.setIcon(imageIcon);
	        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

	        editorFrame.pack();
	        editorFrame.setLocationRelativeTo(null);
	        editorFrame.setVisible(true);*/
	        
		assertNotNull(room);
	}

}
