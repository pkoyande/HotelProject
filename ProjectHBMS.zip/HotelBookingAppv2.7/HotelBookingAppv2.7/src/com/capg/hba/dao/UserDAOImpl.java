package com.capg.hba.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.ui.Client;
import com.capg.hba.util.DBConnection;
import com.capg.hba.util.Util;

public class UserDAOImpl implements IUserDAO {


	// ------------------------ Hotel Booking Application --------------------------
	/*******************************************************************************************************
	 * - Function Name : addUser(User user)
	 * - Input Parameters : User user 
	 * - Return Type : int 
	 * - Throws : ConnectionException
	 * - Author : CAPGEMINI 
	 * - Creation Date : 17/9/2018 
	 * - Description : Adding User
	 ********************************************************************************************************/

	@Override
	public String addUser(User user) throws ConnectionException {
		DBConnection.getInstance();
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String userId = null;
		int id = 0;
		int queryResult = 0;

		try {

			while (true) {
				id = Util.getRandomIntegerBetweenRange();

				userId = "U" + id;
				preparedStatement = connection
						.prepareStatement(QueryMapper.RETRIEVE_USERID_QUERY);
				preparedStatement.setString(1, userId);
				resultSet = preparedStatement.executeQuery();

				if (resultSet.next())
					continue;
				else
					break;

			}// end of while

			preparedStatement = connection
					.prepareStatement(QueryMapper.INSERT_USER_QUERY);
			preparedStatement.setString(1, userId);
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getRole());
			preparedStatement.setString(4, user.getUserName());
			preparedStatement.setString(5, user.getMobileNo());
			preparedStatement.setString(6, user.getPhone());
			preparedStatement.setString(7, user.getAddress());
			preparedStatement.setString(8, user.getEmail());

			queryResult = preparedStatement.executeUpdate();

			if (queryResult == 0) {
				Client.logger.error("Insertion failed ");
				throw new ConnectionException("Inserting user details failed ");

			} else {
				Client.logger.info("User details added successfully:");
				return userId;
			}
		} catch (SQLException e) {
			Client.logger.error("Exception occured while inserting user "+user+" :"+e.getMessage());
			throw new ConnectionException("Inserting user details failed!");
		}
	}//end of addUser method

	// ------------------------ Hotel Booking Application --------------------------
	/*******************************************************************************************************
	 * - Function Name : userSignIn(String userName,String password)
	 * - Input Parameters : String userName,String password
	 * - Return Type : User
	 * -Throws : ConnectionException
	 * - Author : CAPGEMINI
	 * - Creation Date : 17/9/2018 
	 * - Description : Retrieving User if User exists
	 ********************************************************************************************************/

	@Override
	public User userSignIn(String userName, String password, String role)
			throws ConnectionException {
		User newUser = null; //made change here
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.RETRIEVE_USERNAME_PASSWORD_QUERY);
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);
			preparedStatement.setString(3, role);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				newUser = new User();
				newUser.setUserId(resultSet.getString("USER_ID"));
				newUser.setPassword(resultSet.getString("PASSWORD"));
				newUser.setRole(resultSet.getString("ROLE"));
				newUser.setUserName(resultSet.getString("USER_NAME"));
				newUser.setMobileNo(resultSet.getString("MOBILE_NO"));
				newUser.setPhone(resultSet.getString("PHONE"));
				newUser.setAddress(resultSet.getString("ADDRESS"));
				newUser.setEmail(resultSet.getString("EMAIL"));
			}

		} catch (SQLException e) {
			Client.logger.error("Exception while user sign in: "+e.getMessage());
			throw new ConnectionException("Technical problem occured. Refer log.");
		}// end of catch
		finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			}// end of try
			catch (SQLException e) {
				Client.logger.error("Exception while closing db connection: "+e.getMessage());
				throw new ConnectionException("Error in closing db connection");

			}// end of catch
		}
		// end of finally block
		return newUser;
	}//end of UserSignin method

	// ------------------------ Hotel Booking Application --------------------------
	/*******************************************************************************************************
	 * - Function Name : getUser(String userId)
	 * - Input Parameters : String userId 
	 * - Return Type : User
	 * - Throws : ConnectionException
	 * - Author : CAPGEMINI 
	 * - Creation Date : 17/9/2018
	 * - Description : Retrieving User if User exists
	 ********************************************************************************************************/

	@Override
	public User getUser(String userId) throws ConnectionException {
		User newuser = new User();
		DBConnection.getInstance();
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.RETRIEVE_USER_QUERY);
			preparedStatement.setString(1, userId);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				newuser.setUserId(userId);
				newuser.setPassword(resultSet.getString("PASSWORD"));
				newuser.setRole(resultSet.getString("ROLE"));
				newuser.setUserName(resultSet.getString("USER_NAME"));
				newuser.setMobileNo(resultSet.getString("MOBILE_NO"));
				newuser.setPhone(resultSet.getString("PHONE"));
				newuser.setAddress(resultSet.getString("ADDRESS"));
				newuser.setEmail(resultSet.getString("EMAIL"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			Client.logger.error("Exception while retrieving details for user id "+userId+" : "+e.getMessage());
			throw new ConnectionException("Technical problems occured. Refer log.");
		}// end of catch
		finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}// end of try
			catch (SQLException e) {
				Client.logger.error("Exception while closing db connection: "+e.getMessage());
				throw new ConnectionException("Error in closing db connection");

			}// end of catch
		}// end of finally block
		return newuser;

	}//end of getUser method


}
