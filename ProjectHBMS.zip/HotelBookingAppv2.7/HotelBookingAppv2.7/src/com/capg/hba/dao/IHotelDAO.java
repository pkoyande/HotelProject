package com.capg.hba.dao;

import java.util.List;

import com.capg.hba.bean.Hotel;
import com.capg.hba.exceptions.ConnectionException;

public interface IHotelDAO {
	// DONE
	// Dealing with Hotel table
	// make function in room dao to count no of rooms in a hotel
	public String adminAddHotel(Hotel hotel) throws ConnectionException;

	public boolean adminDeleteHotel(String hotelId) throws ConnectionException;

	public boolean adminModifyHotel(Hotel hotel) throws ConnectionException;

	public List<Hotel> adminViewHotels() throws ConnectionException;

	public Hotel getHotel(String hotelId) throws ConnectionException;

	List<Hotel> userSearchHotels(String city, String address, double avgRate,
			int rating) throws ConnectionException;
}
