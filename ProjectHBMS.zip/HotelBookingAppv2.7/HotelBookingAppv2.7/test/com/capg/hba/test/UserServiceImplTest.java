package com.capg.hba.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.service.IUserService;
import com.capg.hba.service.UserServiceImpl;

public class UserServiceImplTest {
	
	static IUserService serv=null;
	
	@BeforeClass
	public static void setUpBeforeClass(){
		serv=new UserServiceImpl();	
	} 
	
	@Test
	public void userSignInTest(){
		String username="akash";
		String password="Akashh";
		
		try {
			assertNotNull(serv.userSignIn(username, password));
		} catch (ConnectionException e1) {
			e1.printStackTrace();
		}
		try {
			assertNull(serv.userSignIn(username,username+password));
		} catch (ConnectionException e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void userBookRoomTest(){
		Booking b=new Booking();
		Room room=new Room();
		User user=new User();
		room.setRoomId("R408");
		user.setUserId("U996");
		b.setRoom(room);
		b.setUser(user);
		b.setNoOfAdults(1);
		b.setNoOfChildren(1);
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date parsedFrom=null;
		try {
			parsedFrom = format.parse("2018/12/04");
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		Date date1= new java.sql.Date(parsedFrom.getTime());
		try {
			parsedFrom = format.parse("2018/12/07");
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		Date date2=new java.sql.Date(parsedFrom.getTime());

		b.setBookedFrom(date1);
		b.setBookedTo(date2);
		try {
			assertNotNull(serv.userBookRoom(b));
		} catch (ConnectionException e) {
			Assert.fail(e.getMessage());
		}
		
		user.setUserId("");
		room.setRoomId("");

		
		try {
			System.out.println(serv.userBookRoom(b));
			assertEquals("true",serv.userBookRoom(b));
		} catch (ConnectionException e) {
			Assert.fail(e.getMessage());
			
		}
	}

}
