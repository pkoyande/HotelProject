package com.capg.hba.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.hba.bean.Hotel;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.service.AdminServiceImpl;
import com.capg.hba.service.IAdminService;

public class AdminServiceImplTest {
	
	static IAdminService serv=null;
	
	@BeforeClass
	public static void setUpBeforeClass(){
		serv=new AdminServiceImpl();	
	}
	
	@Test
	public void adminLoginTest() throws ConnectionException{
		String username="admin";
		String password="admin";
		
		assertNotNull(serv.adminLogin(username, password));
		assertNull(serv.adminLogin(username, username+password));
				
	}
	
	@Test
	public void adminModifyHotelTest(){
		Hotel h=new Hotel();
		h.setHotelId("H437");
		h.setHotelName("Annapurna");
		h.setAddress("andheri");
		h.setAvgRatePerNight(2500);
		h.setEmail("annapurna@gm.com");
		h.setDescription("Couple friendly");
		h.setCity("Mumbai");
		try {
			assertTrue(serv.adminModifyHotel(h));
		} catch (ConnectionException e1) {
			e1.printStackTrace();
		}
		
		h.setHotelId("H433");
		try {
			serv.adminModifyHotel(h);
		} catch (ConnectionException e) {
			assertTrue(true);
		}
	}

}
