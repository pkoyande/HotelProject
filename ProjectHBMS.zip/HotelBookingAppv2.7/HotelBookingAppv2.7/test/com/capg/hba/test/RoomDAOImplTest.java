package com.capg.hba.test;

import static org.junit.Assert.*;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import org.junit.Test;

import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.dao.RoomDAOImpl;
import com.capg.hba.exceptions.ConnectionException;

public class RoomDAOImplTest {

	@Test
	public void testUserSearchRooms() {
		fail("Not yet implemented");
	}

	@Test
	public void testAdminAddRoom() throws ConnectionException {
		//fail("Not yet implemented");
		Hotel hotel = new Hotel();
		hotel.setHotelId("H121");
		Room room = new Room();
		room.setRoomNo("202");
		room.setAvailability(true);
		room.setHotel(hotel);
		room.setPerNightRate(2000);
		//room.setRoomId("R132");
		room.setRoomType("Standard non A/C room");
		
		BufferedImage img = null;

		try 
		{
		    img = ImageIO.read(new File("D:/Capture1.png")); 
		} 
		catch (IOException e) 
		{
		    e.printStackTrace();
		}
		
		room.setPhoto(img);
		
		RoomDAOImpl dao = new RoomDAOImpl();
		System.out.println("1");
		assertNotNull("Returned null!",dao.adminAddRoom(room));
		System.out.println("2");
	}



	@Test
	public void testAdminModifyRoom() throws ConnectionException {
		RoomDAOImpl rdao = new RoomDAOImpl();
		Room room = rdao.getRoom("R298");
		//System.out.println(room.getRoomNo());
		room.setRoomNo("356");
		boolean n = rdao.adminModifyRoom(room);
		System.out.println("Update: "+n);
		assertTrue(n);
		
	}

	@Test
	public void testGetRoom() throws ConnectionException, InterruptedException {
		RoomDAOImpl rdao = new RoomDAOImpl();
		Room room = rdao.getRoom("R463");
		BufferedImage image = room.getPhoto();
		 JFrame editorFrame = new JFrame("Image Demo");
	        editorFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	        ImageIcon imageIcon = new ImageIcon(image);
	        JLabel jLabel = new JLabel();
	        jLabel.setIcon(imageIcon);
	        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

	        editorFrame.pack();
	        editorFrame.setLocationRelativeTo(null);
	        editorFrame.setVisible(true);
	        
		assertNotNull(room);
	}
	@Test
	public void testAdminDeleteRoom() throws ConnectionException {
		RoomDAOImpl rdao = new RoomDAOImpl();
		assertTrue(rdao.adminDeleteRoom("R463"));
	}

}
