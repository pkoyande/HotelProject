package com.capg.hba.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.hba.bean.Booking;
import com.capg.hba.dao.BookingDAOImpl;
import com.capg.hba.exceptions.ConnectionException;

public class BookingDAOImplTest {

	static BookingDAOImpl dao=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	dao=new BookingDAOImpl();
	}

	@Test
	public void testAdminViewBookingsForHotel() {
		/*String id="H584";
		try {
			List<Booking> book=dao.adminViewBookingsForHotel(id);
			System.out.println(book.get(0).getBookingId() );
			System.out.println( book.get(1).getBookingId());
		} catch (ConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	@Test
	public void testAdminViewBookingsForDate() {
		//fail("Not yet implemented");
		 String str="2015-04-01";  
		    Date date=Date.valueOf(str);
		try {
			List<Booking> book=dao.adminViewBookingsForDate(date);
			
			System.out.println(book.get(0).getBookingId() );
			System.out.println( book.get(1).getBookingId());
		} catch (ConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetBooking() {
		/*String book="B443";
		Booking b=new Booking();
		try {
			b=dao.getBooking(book);
			System.out.println(b.getAmount());
		} catch (ConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	@Test
	public void testAdminAddBooking() {
		//fail("Not yet implemented");
		/*Booking booking =new Booking();
		booking.setRoomId("R123");
		booking.setUserId("U321");
		  String str="2015-03-31";  
		    Date date=Date.valueOf(str);
		booking.setBookedFrom(date);
		  str="2015-04-03";  
		     date=Date.valueOf(str);
		booking.setBookedTo(date);
		booking.setNoOfAdults(2);
		booking.setNoOfChildren(4);
		booking.setAmount(2345.1);
		
		try {
			assertEquals(1,dao.adminAddBooking(booking) );
		} catch (ConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

}
