package com.capg.hba.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.PropertyConfigurator;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.hba.bean.Hotel;
import com.capg.hba.dao.HotelDAOImpl;
import com.capg.hba.exceptions.ConnectionException;

public class HotelDAOImplTest {

	public static HotelDAOImpl dao = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		PropertyConfigurator.configure("resources//log4jAdmin.properties");
		dao = new HotelDAOImpl();
	}

	@Test
	public void testUserSearchHotels() {
		Hotel h = new Hotel();
		Hotel h1 = new Hotel();
		Hotel h2 = new Hotel();
		h.setCity("mumbai");
		h.setAddress("Andheri");
		h.setRating(3);
		h.setAvgRatePerNight(4000);
		h2.setCity("Pune");
		h2.setAddress("Nigdi");

		try {
			assertFalse((dao.userSearchHotels(h.getCity(), h.getAddress(),
					h.getAvgRatePerNight(), h.getRating())).isEmpty());
			assertTrue((dao.userSearchHotels(h2.getCity(), h2.getAddress(),
					h2.getAvgRatePerNight(), h2.getRating())).isEmpty());

		} catch (ConnectionException e) {
			e.printStackTrace(); // doubt regarding AvgRatePerNight
		}

	}

	@Test
	public void testAdminAddHotel() {
		Hotel h = new Hotel();
		h.setHotelName("Krishna Regency");
		h.setCity("Pune");
		h.setAddress("Nigdi");
		h.setAvgRatePerNight(2000);
		h.setEmail("kr@gmail.com");
		h.setFax("020276406122345");
		h.setDescription("This hotel is near to nigdi Bus Stop.");
		h.setPhoneNo1("0774494998");
		h.setPhoneNo2("0774494998");
		h.setRating(3);
		Hotel h1 = new Hotel();

		try {
			assertNotNull(dao.adminAddHotel(h));
			dao.adminAddHotel(h1);
		} catch (NullPointerException e) {
			e.printStackTrace();
		} catch (ConnectionException e) {
			assertTrue(true);
		}

	}

	@Test
	public void testAdminDeleteHotel() {

		try {
			assertEquals(true, dao.adminDeleteHotel("H562"));
		} catch (ConnectionException e) {
			e.printStackTrace();
		}
		try {
			dao.adminDeleteHotel("H981");
		} catch (ConnectionException e) {
			assertFalse(false);
		}

	}

	@Test
	public void testAdminModifyHotel() {

		Hotel h = new Hotel();
		h.setHotelId("H829");
		h.setHotelName("Krishna Regency");
		h.setCity("Pune");
		h.setAddress("Magarpatta");
		h.setAvgRatePerNight(2000);
		h.setEmail("kr@gmail.com");
		h.setFax("020276406122345");
		h.setDescription("This hotel is in front of  nigdi Bus Stop.");
		h.setPhoneNo1("0774494998");
		h.setPhoneNo2("0774494998");
		h.setRating(3);

		try {
			assertTrue(dao.adminModifyHotel(h));
		} catch (ConnectionException e) {
			e.printStackTrace();
		}

		h.setHotelId("H543");
		try {
			dao.adminModifyHotel(h);
		} catch (ConnectionException e) {
			assertTrue(true);
		}

	}

	@Test
	public void testAdminViewHotels() {

		try {
			List<Hotel> h = new ArrayList<Hotel>();
			h = dao.adminViewHotels();
			assertFalse(h.isEmpty());
			assertEquals("H437", h.get(0).getHotelId());
		} catch (ConnectionException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetHotel() {

		try {
			Hotel hotel = new Hotel();
			assertNotNull(dao.getHotel("H437"));
			assertNull(dao.getHotel("H981"));
		} catch (ConnectionException e) {
			e.printStackTrace();
		}

	}
}
