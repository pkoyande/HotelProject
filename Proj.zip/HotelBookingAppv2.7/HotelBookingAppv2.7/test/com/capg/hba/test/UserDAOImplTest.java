package com.capg.hba.test;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.PropertyConfigurator;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.hba.bean.User;
import com.capg.hba.dao.UserDAOImpl;
import com.capg.hba.exceptions.ConnectionException;

public class UserDAOImplTest {
	public static UserDAOImpl dao;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		PropertyConfigurator.configure("resources//log4jAdmin.properties");
		dao = new UserDAOImpl();
	}

	@Test
	public void testAddUser() {
		
		User u=new User(); u.setUserName("Nisarg"); u.setRole("user");
		 u.setPassword("prst"); u.setMobileNo("8574695478");
		 u.setPhone("5424896871"); u.setAddress("Kalidas");
		 u.setEmail("sdfduhf@cag.com");
		 
		 try { assertEquals(1, dao.addUser(u)); } catch (ConnectionException
		 e) { e.printStackTrace(); }
		 

	}

	@Test
	public void testUserSign() {
		/*
		 * User u=new User(); u.setUserId("U234"); u.setUserName("Nisarg");
		 * u.setRole("user"); u.setPassword("prst");
		 * u.setMobileNo("8574695478"); u.setPhone("5424896871");
		 * u.setAddress("Kalidas"); u.setEmail("sdfduhf@cag.com");
		 */

		try {

			// System.out.println("ramu"+dao.userSignIn("Nisarg","prst"));
			assertEquals("U931", (dao.userSignIn("Nisarg", "prst", "USER")).getUserId()); // Check
																					// user
																					// sign
																					// in
																					// and
																					// password
																					// check
			// System.out.println( "fchfg"
			// +dao.userSignIn("Nisarg","prst").getUserId());
		} catch (ConnectionException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testgetUser() {
		User u = new User();
		u.setUserId("U234");
		u.setUserName("Nisarg");
		u.setRole("user");
		u.setPassword("prst");
		u.setMobileNo("8574695478");
		u.setPhone("5424896871");
		u.setAddress("Kalidas");
		u.setEmail("sdfduhf@cag.com");

		try {
			assertEquals("Kalidas", (dao.getUser("U931")).getAddress()); // Check
																			// user
																			// sign
																			// in
																			// and
																			// password
																			// check
		} catch (ConnectionException e) {
			e.printStackTrace();
		}
	}

}
