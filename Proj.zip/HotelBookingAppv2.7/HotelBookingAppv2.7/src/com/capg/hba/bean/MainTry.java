/*package com.capg.hba.bean;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.imageio.ImageIO;

import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.util.DBConnection;

public class MainTry {

	public static void main(String[] args) throws ConnectionException, IOException {
		// TODO Auto-generated method stub

		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement pstmt = null;
		try {
			pstmt = connection.prepareStatement("Insert into images values (?)");
			File blobFile = new File("D:\\Users\\sthawait\\Downloads\\download1.jpg");
			InputStream in = new FileInputStream(blobFile);
			pstmt.setBinaryStream(1, in, (int)blobFile.length());
			pstmt.executeUpdate();
			connection.commit();
			
			
	        File f = new File("D:\\Users\\sthawait\\Downloads\\download1.jpg");
	        String filename = "roomImages//room123.jpg";
	        File g = new File(filename);
	        //copyFileUsingStream(f, g);
	        
	        //File outputfile = new File("image.jpg");
	        BufferedImage bufferedImage = ImageIO.read(f);
			ImageIO.write(bufferedImage, "jpg", g);
	  
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static void copyFileUsingStream(File source, File dest) throws IOException {
	    InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = new FileInputStream(source);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    } finally {
	        is.close();
	        os.close();
	    }
	}

}
*/