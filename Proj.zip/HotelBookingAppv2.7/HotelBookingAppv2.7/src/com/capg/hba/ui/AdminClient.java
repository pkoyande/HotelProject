package com.capg.hba.ui;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.service.AdminServiceImpl;
import com.capg.hba.service.IAdminService;
import com.capg.hba.service.IUserService;
import com.capg.hba.service.UserServiceImpl;
import com.capg.hba.util.Util;

public class AdminClient {

	IAdminService adminService = new AdminServiceImpl();

	public User adminLogIn() {
		int count = 0;
		User user = null;

		while (count < Client.ATTEMPTS) {

			count++;

			Client.printHeading("ADMIN LOGIN");
			System.out.println("Maximum 3 attempts allowed.");
			Client.printLineBreak();

			System.out.println("Enter Username:");

			String userName = Client.sc.next();

			System.out.println("Enter Password:");

			String password = Client.sc.next();

			try {
				user = adminService.adminLogin(userName, password);
			} catch (ConnectionException e) {
				e.printStackTrace();
			}

			if (user == null) {

				Client.printError("The username or password you entered is incorrect!");
				continue;

			}// end of if

			else {

				break;

			}
		}// end of while count

		if (count >= Client.ATTEMPTS && user==null) {

			Client.printError("You have exceeded maximum number of attempts!");
			return null;
		}// end of if

		return user;

	}// end of method

	public void performHotelManagement() {

		int option1 = 0;
		Hotel hotel = null;
		String hotelId = null;

		loop1: while (true) {

			Client.printHeading("PERFORM HOTEL MANAGEMENT");
			System.out.println("1. Add a new hotel to database."); // Done
			System.out.println("2. Modify an existing hotel in database.");
			System.out.println("3. Delete an existing hotel in database.");
			System.out.println("4. Go to previous menu.\n");


			option1 = Client.inputOption();

			switch (option1) {

			case 1:

				addHotel();
				break;

			case 2:

				modifyHotel();
				break;

			case 3:

				deleteHotel();
				break;

			case 4:
				return;

			default:
				Client.printError("Please enter a valid option!");
			}
		}
	}// end of method

	private void deleteHotel() {

		String hotelId;
		Client.printHeading("DELETE HOTEL");

		System.out.println("Enter the hotel ID of hotel to be deleted:");

		hotelId = Client.sc.next();
		try {
			if (adminService.adminDeleteHotel(hotelId)) {
				Client.printInfo("Hotel deleted from database.");
			} else {
				Client.printError("Hotel could not be deleted.");
			}
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}

	}// end of method

	private void modifyHotel() {
		int option = 0;
		String hotelId = null;
		Hotel hotel = null;
		Client.printHeading("MODIFY HOTEL DETAILS");

		System.out.println("Enter Hotel Id of Hotel to be modified:");

		hotelId = Client.sc.next();

		try {
			hotel = adminService.getHotel(hotelId);
		} catch (ConnectionException e) {
			e.printStackTrace();
		}

		if (hotel != null) {

			loop1: while (true) {

				Client.printHeading("Select the details to be modified");

				displayHotel(hotel);
				System.out.println("\n");

				System.out.println("1. City");
				System.out.println("2. Hotel Name");
				System.out.println("3. Hotel Address");
				System.out.println("4. Hotel Description");
				System.out.println("5. Average rate Per Night");
				System.out.println("6. First Phone number");
				System.out.println("7. Second Phone number");
				System.out.println("8. Rating");
				System.out.println("9. Email Id");
				System.out.println("10. Fax");
				System.out
						.println("11. Update hotel with the modified details");
				System.out.println("12. Go to previous menu\n");

				option = Client.inputOption();

				switch (option) {

				case 1:

					String city;

					while (true) {
						System.out.println("Enter the modified City:");
						city = Client.sc.next();
						if (adminService.validateCity(city)) {
							break;
						} else {
							Client.printError("Please enter the available cities.");
						}
					}

					hotel.setCity(city);
					break;

				case 2:

					String hotelName;

					while (true) {
						System.out
								.println("Enter the modified name of the hotel:");
						Client.sc.nextLine();
						hotelName = Client.sc.nextLine();
						if (adminService.validateHotelName(hotelName)) {
							break;
						} else {
							Client.printError("Hotel Name Length should be less than 20");
						}
					}

					hotel.setHotelName(hotelName);
					break;

				case 3:

					String address;

					while (true) {
						System.out.println("Enter the address of the hotel:");
						Client.sc.nextLine();
						address = Client.sc.nextLine();
						if (adminService.validateAddress(address)) {
							break;
						} else {
							Client.printError("Length should be less than 25");
						}
					}

					hotel.setAddress(address);
					break;

				case 4:

					String description;

					while (true) {
						System.out
								.println("Enter the modified description (max 50 letters):");
						Client.sc.nextLine();
						description = Client.sc.nextLine();
						if (adminService.validateDescription(description)) {
							break;
						} else {
							Client.printError("Description Length should be less than 50");
						}
					}

					hotel.setDescription(description);
					break;

				case 5:

					double avgRate;

					while (true) {
						System.out
								.println("Enter the modified average rate per night:");
						try {
							avgRate = Client.sc.nextDouble();
						} catch (InputMismatchException e) {
							Client.sc.nextLine();
							Client.printError("Please enter numeric value!");
							continue;
						}
						if (adminService.validateRate(avgRate)) {
							break;
						} else {
							Client.printError("Rate must be greater than 0");
						}
					}

					hotel.setAvgRatePerNight(avgRate);
					break;

				case 6:
					String phone1;

					while (true) {
						System.out
								.println("Enter the modified phone number 1:");
						phone1 = Client.sc.next();
						if (adminService.validatePhoneNo(phone1)) {
							break;
						} else {
							Client.printError("Invalid Number!! Phone number has to be of 10 digits And should start with 0 or 91");
						}
					}

					hotel.setPhoneNo1(phone1);
					break;

				case 7:

					String phone2;

					while (true) {
						System.out
								.println("Enter the modified phone number 1:");
						phone2 = Client.sc.next();
						if (adminService.validatePhoneNo(phone2)) {
							break;
						} else {
							Client.printError("Invalid Number!! Phone number has to be of 10 digits And should start with 0 or 91");
						}
					}

					hotel.setPhoneNo2(phone2);
					break;

				case 8:

					int rating;

					while (true) {
						System.out
								.println("Enter the modified rating between 1 to 5:");
						try {
							rating = Client.sc.nextInt();
						} catch (InputMismatchException e) {
							Client.sc.nextLine();
							Client.printError("Please enter numeric value!");
							continue;
						}

						if (adminService.validateRating(rating)) {
							break;
						} else {
							Client.printError("Invalid rating!! Rate on the scale of 5!!");
						}

					}

					hotel.setRating(rating);
					break;

				case 9:
					String email;

					while (true) {
						System.out.println("Enter modified email ID:");
						email = Client.sc.next();
						if (adminService.validateEmail(email)) {
							break;
						} else {
							Client.printError("Email is Invalid!!");
						}
					}

					hotel.setEmail(email);
					break;

				case 10:

					String fax;
					while (true) {
						System.out.println("Enter the modified fax number:");
						fax = Client.sc.next();
						if (adminService.validateFax(fax)) {
							break;
						} else {
							Client.printError("Fax number must be of 5 to 8 length for Local or 9 to 10 for National");
						}
					}

					hotel.setFax(fax);
					break;

				case 11:

					try {
						if (adminService.adminModifyHotel(hotel)) {
							System.out.println("Hotel modified successfully!");
						} else {
							Client.printError("Hotel could not be modified!");
						}
					} catch (ConnectionException e) {
						Client.printError(e.getMessage());
					}
					return;

				case 12:

					return;

				default:

					Client.printError("Please enter a valid option!");

				}// end of switch

			}// end of loop

		}// end of if
		else {
			Client.printError("Invalid hotel Id!");
		}// end of else
	}// end of method

	private void addHotel() {

		Hotel hotel = null;
		String hotelId = null;
		Client.printHeading("ADD HOTEL TO DATABASE");

		hotel = populateHotel();

		try {
			hotelId = adminService.adminAddHotel(hotel);
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}
		if (hotelId != null) {
			Client.printInfo("Hotel added to the database. Hotel ID is "
					+ hotelId);
		} else {
			Client.printError("Hotel not added!");
		}
	}// end of method

	private Hotel populateHotel() {
		Hotel hotel = new Hotel();

		String city;
		String hotelName;
		String address;
		String description;
		Double avgRate;
		String phone1;
		String phone2;
		int rating;
		String email;
		String fax;

		while (true) {
			System.out.print("Select the City-");
			List<String> cities = Util.citylist();
			/*int i = 1;
			for (String c : cities) {
				System.out.println(i+". "+c);
			}*/
			
			//int option = Client.inputOption();
			
			city = Client.sc.next();
			if (adminService.validateCity(city)) {
				break;
			} else {
				Client.printError("Please enter the available cities.");
			}
		}

		while (true) {
			System.out.println("Enter the name of the hotel:");
			Client.sc.nextLine();
			hotelName = Client.sc.nextLine();
			if (adminService.validateHotelName(hotelName)) {
				break;
			} else {
				Client.printError("Hotel Name Length should be less than 20");
			}
		}

		while (true) {
			System.out.println("Enter the address of the hotel:");
			// sc.nextLine();
			address = Client.sc.nextLine();
			if (adminService.validateAddress(address)) {
				break;
			} else {
				Client.printError("Length should be less than 25");
			}
		}

		while (true) {
			System.out
					.println("Enter a short description of the hotel (max 50 letters):");
			// sc.nextLine();
			description = Client.sc.nextLine();
			if (adminService.validateDescription(description)) {
				break;
			} else {
				Client.printError("Description Length should be less than 50");
			}
		}

		while (true) {
			System.out.println("Enter the average rate per night:");
			try {
				avgRate = Client.sc.nextDouble();
			} catch (InputMismatchException e) {
				Client.sc.nextLine();
				Client.printError("Please enter numeric value!");
				continue;
			}
			if (adminService.validateRate(avgRate)) {
				break;
			} else {
				Client.printError("Rate must be greater than 0");
			}
		}

		while (true) {
			System.out.println("Enter phone number 1:");
			phone1 = Client.sc.next();
			if (adminService.validatePhoneNo(phone1)) {
				break;
			} else {
				Client.printError("Invalid Number!! Phone number has to be of 10 digits And should start with 0 or 91");
			}
		}

		while (true) {
			System.out.println("Enter phone number 2:");
			phone2 = Client.sc.next();
			if (adminService.validatePhoneNo(phone2)) {
				break;
			} else {
				Client.printError("Invalid Number!! Phone number has to be of 10 digits And should start with 0 or 91");
			}
		}

		while (true) {
			System.out.println("Enter the rating between 1 to 5:");
			try {
				rating = Client.sc.nextInt();
			} catch (InputMismatchException e) {
				Client.sc.nextLine();
				Client.printError("Please enter numeric value!");
				continue;
			}

			if (adminService.validateRating(rating)) {
				break;
			} else {
				Client.printError("Invalid rating!! Rate on the scale of 5!!");
			}

		}

		while (true) {
			System.out.println("Enter email ID:");
			email = Client.sc.next();
			if (adminService.validateEmail(email)) {
				break;
			} else {
				Client.printError("Email is Invalid!!");
			}
		}

		while (true) {
			System.out.println("Enter fax number:");
			fax = Client.sc.next();
			if (adminService.validateFax(fax)) {
				break;
			} else {
				Client.printError("Fax number must be of 5 to 8 length for Local or 9 to 10 for National");
			}
		}

		hotel.setAddress(address);
		hotel.setAvgRatePerNight(avgRate);
		hotel.setCity(city);
		hotel.setDescription(description);
		hotel.setEmail(email);
		hotel.setFax(fax);
		hotel.setHotelName(hotelName);
		hotel.setPhoneNo1(phone1);
		hotel.setPhoneNo2(phone2);
		hotel.setRating(rating);

		return hotel;
	}// end of method

	private static void displayHotel(Hotel hotel) {
		String leftAlignFormat = "| %-4s | %-10s | %-20s | %-25s | %-50s | %-22s | %-6d |%n";

		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+%n");
		System.out
				.format("| ID   | City       | Hotel Name           | Address                   | Description                                        | Average Rate per night | Rating |%n");
		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+%n");

		System.out.format(leftAlignFormat, hotel.getHotelId(), hotel.getCity(),
				hotel.getHotelName(), hotel.getAddress(),
				hotel.getDescription(),
				new Double(hotel.getAvgRatePerNight()).toString(),
				hotel.getRating());
		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+%n");
	}// end of method

	public void performRoomManagement() {

		int option1 = 0;

		loop1: while (true) {

			Client.printHeading("PERFORM ROOM MANAGEMENT");
			System.out.println("1. Add a new room to database.");
			System.out.println("2. Modify an existing room in database.");
			System.out.println("3. Delete an existing room in database.");
			System.out.println("4. Go to previous menu.\n");

			option1 = Client.inputOption();

			switch (option1) {

			case 1: // add room

				addRoom();
				break;

			case 2: // modify room
				modifyRoom();

			case 3: // delete room
				deleteRoom();

			case 4:
				return;

			default:

				Client.printError("Please enter a valid option!");

			}
		}// end of loop9
	}// end of method

	private void deleteRoom() {

		String roomId;
		Client.printHeading("DELETE ROOM");

		System.out.println("Enter the room ID of hotel to be deleted:");

		roomId = Client.sc.next();
		try {
			if (adminService.adminDeleteRoom(roomId)) {
				Client.printInfo("Room deleted from database.");
			} else {
				Client.printError("Room could not be deleted.");
			}
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}
	}

	private void modifyRoom() {
		// TODO Auto-generated method stub
		int option = 0;
		String roomId = null;
		Room room = null;
		Client.printHeading("MODIFY ROOM DETAILS");

		System.out.println("Enter Room Id of Hotel to be modified:");

		roomId = Client.sc.next();

		try {
			room = adminService.getRoom(roomId);
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}

		if (room != null) {

			loop1: while (true) {

				Client.printHeading("Select the details to be modified");

				displayRoom(room);
				System.out.println("\n");

				System.out.println("1. Room Number");
				System.out.println("2. Room Type");
				System.out.println("3. Rate Per Night");
				System.out.println("4. Photo");
				System.out
						.println("5. Update room with the modified details");
				System.out.println("6. Go to previous menu\n");

				option = Client.inputOption();

				switch (option) {

				case 1:

					String roomNo;

					while (true) {
						System.out.println("Enter modified Room No");
						roomNo = Client.sc.next();

						if (adminService.validateRoomNo(roomNo)) {
							break;
						} else {
							System.out.println("Enter valid Room_no between 100 to 999");
						}
					}

					room.setRoomNo(roomNo);
					break;

				case 2:

					String roomType;

					Loop: while (true) {
						System.out.println("Choose a modified Room Type ");
						for (int i = 0; i < Util.roomList().size(); i++)
							System.out.println(i + ". " + Util.roomList().get(i));
						int choice = Client.sc.nextInt();
						switch (choice) {
						case 0:
							roomType = Util.roomList().get(choice);
							break Loop;
						case 1:
							roomType = Util.roomList().get(choice);
							break Loop;
						case 2:
							roomType = Util.roomList().get(choice);
							break Loop;
						case 3:
							roomType = Util.roomList().get(choice);
							break Loop;
						default:
							System.out.println("Enter valid choice");
							break;
						}// end of switch case
					}

					room.setRoomType(roomType);
					break;

				case 3:

					Double rate;

					while (true) {
						System.out.println("Enter modified Per Night Rate for Room");
						rate = Client.sc.nextDouble();
						if (adminService.validateRate(rate)) {
							break;
						}// end of if
						else {
							System.out
									.println("Enter Valid Rate.Rate has to be less than 10,00,000");
						}// end of else

					}// end of while

					room.setPerNightRate(rate);
					break;

				case 4:

					BufferedImage img;
					String path;
					while (true) {
						System.out.println("Enter the System Path for Photo");
						path = Client.sc.next();
						try {
							img = ImageIO.read(new File(path));
							if (img == null) {
								Client.printError("Image doesnot exist");
							}// end of if
							else
								break;
						}// end of try
						catch (IOException e) {
							Client.sc.nextLine();
							Client.printError("Enter a valid path!"+e.getMessage());
						}// end of catch
					}// end of while
					
/*					room.setPhoto(img);
*/					room.setPhotoPath(path);
					break;
				

				case 5:

					try {
						if (adminService.adminModifyRoom(room)) {
							Client.printInfo("Room modified successfully!");
						} else {
							Client.printError("Room could not be modified!");
						}
					} catch (ConnectionException e) {
						// TODO Auto-generated catch block
						Client.printError(e.getMessage());
					}
					return;

				case 6:

					return;

				default:

					Client.printError("Please enter a valid option!");

				}// end of switch

			}// end of loop

		}// end of if
		else {
			Client.printError("Invalid room Id!");
		}// end of else

	}// end of method

	private void displayRoom(Room room) {

		String leftAlignFormat = "| %-7s | %-8s | %-7s | %-20s | %-14s | %-12s |%n";
		System.out
				.format("+---------+----------+---------+----------------------+----------------+--------------+%n");
		System.out
				.format("| Room Id | Hotel Id | Room No | Room Type            | Rate per night | Availability |%n");
		System.out
				.format("+---------+----------+---------+----------------------+----------------+--------------+%n");
		System.out.format(leftAlignFormat, room.getHotel().getHotelName(), room
				.getHotel().getAddress(), room.getHotel().getCity(), room
				.getRoomNo(), room.getRoomType(),
				new Double(room.getPerNightRate()).toString());
		System.out
				.format("+---------+----------+---------+----------------------+----------------+--------------+%n");

		/*JFrame editorFrame = new JFrame("Image of room");
        editorFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        ImageIcon imageIcon = new ImageIcon(room.getPhoto());
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);*/
	}

	private void addRoom() {
		Room room = null;
		String roomId = null;
		Client.printHeading("ADD ROOM TO DATABASE");

		room = populateRoom();

		try {
			roomId = adminService.adminAddRoom(room);
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}
		if (roomId != null) {
			Client.printInfo("Room added to the database. Room ID is "
					+ roomId);
		} else {
			Client.printError("Room not added!");
		}
	}// end of method

	private Room populateRoom() {
		String hotel_id = null;
		String room_no = null;
		String room_type = null;
		int choice = 0;
		double rate = 0.00;
		String path = null;
		BufferedImage img = null;
		Room room = new Room();
		Hotel hotel = null;
		// changed here
		while (true) {
			System.out.println("Enter the Hotel id");
			hotel_id = Client.sc.next();
			try {
				hotel = adminService.getHotel(hotel_id);
			} catch (ConnectionException e) {
				// TODO Auto-generated catch block
				Client.sc.nextLine();
				e.printStackTrace();
			}
			if (hotel == null) {
				Client.printError("Invalid hotel Id!");
			} else {
				break;
			}
		}

		while (true) {
			System.out.println("Enter Room No");
			room_no = Client.sc.next();

			if (adminService.validateRoomNo(room_no)) {
				break;
			} else {
				System.out.println("Enter valid Room_no between 100 to 999");
			}
		}
		Loop: while (true) {
			System.out.println("Choose a Room Type ");
			for (int i = 0; i < Util.roomList().size(); i++)
				System.out.println(i + ". " + Util.roomList().get(i));
			choice = Client.sc.nextInt();
			switch (choice) {
			case 0:
				room_type = Util.roomList().get(choice);
				break Loop;
			case 1:
				room_type = Util.roomList().get(choice);
				break Loop;
			case 2:
				room_type = Util.roomList().get(choice);
				break Loop;
			case 3:
				room_type = Util.roomList().get(choice);
				break Loop;
			default:
				System.out.println("Enter valid choice");
				break;
			}// end of switch case
		}

		while (true) {
			System.out.println("Enter Per Night Rate for Room");
			rate = Client.sc.nextDouble();
			if (adminService.validateRate(rate)) {
				break;
			}// end of if
			else {
				System.out
						.println("Enter Valid Rate.Rate has to be less than 10,00,000");
			}// end of else

		}// end of while

		
		while (true) {
			System.out.println("Enter the System Path for Photo");
			path = Client.sc.next();
			try {
				img = ImageIO.read(new File(path));
				if (img == null) {
					Client.printError("Image doesnot exist");
				}// end of if
				else
					break;
			}// end of try
			catch (IOException e) {
				Client.sc.nextLine();
				Client.printError("Enter a valid path!"+e.getMessage());
			}// end of catch
		}// end of while

		room.setHotel(hotel);
		room.setRoomNo(room_no);
		room.setRoomType(room_type);
		room.setPerNightRate(rate);
		room.setAvailability(true);
/*		room.setPhoto(img);
*/		return room;
	}// end of method

	public void generateReports() {

		String hotelId;
		Hotel hotel;

		int option = 0;
		while (true) {
			Client.printHeading("GENERATE REPORTS");
			System.out.println("1. View list of hotels.");
			System.out.println("2. View Bookings of specific hotel.");
			System.out.println("3. View guest list of specific hotel.");
			System.out.println("4. View bookings for specified date");
			System.out.println("5. Go to previous menu.\n");

			option = Client.inputOption();

			switch (option) {

			case 1: // list of hotels

				try {
					displayHotels(adminService.adminViewHotels());
				} catch (ConnectionException e) {
					Client.printError(e.getMessage());
				}
				break;

			case 2: // bookings of a hotel

				System.out.println("Enter Hotel Id: ");
				hotelId = Client.sc.next();
				hotel = null;
				try {
					hotel = adminService.getHotel(hotelId);
					if (hotel != null) {
						List <Booking> bookings = adminService
								.adminViewBookingsForHotel(hotelId);
						if(bookings.size()>0){
							displayBookings(bookings);
						}
						else{
							Client.printInfo("No bookings found.");
						}
						
					} else {
						Client.printError("Invalid hotel ID!");

					}
				} catch (ConnectionException e) {
					Client.printError(e.getMessage());
				}

				break;

			case 3: // guest list of a hotel

				System.out.println("Enter the hotel Id: ");
				hotelId = Client.sc.next();
				hotel = null;
				try {
					hotel = adminService.getHotel(hotelId);
					if (hotel != null) {
						HashMap<Booking, User> guests = adminService
								.adminViewGuestList(hotelId);
						if(guests.size()>0){
							displayGuestList(guests);
						}
						else{
							Client.printInfo("No guests found.");
						}
					} else {
						Client.printError("Invalid hotel ID!");

					}
				} catch (ConnectionException e) {
					Client.printError(e.getMessage());
				}

				break;

			case 4: // bookings for a specified date
				java.util.Date parsedFrom = null;
				while (true) {
					IUserService userService = new UserServiceImpl();
					System.out.println("Enter the check-in date:");
					System.out.println("Date format is yyyy/MM/dd ");

					SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

					String date = Client.sc.next();
					try {

						if (userService.validateDate(date)) {
							parsedFrom = format.parse(date);
							break;
						} else
							Client.printError("Enter Date as per given Format yyyy/MM/dd");
					} catch (ParseException e2) {
						Client.printError("Enter a valid date!");
					}
				}
				Date bookingDate = new java.sql.Date(parsedFrom.getTime());
				try {
					List<Booking> bookings = adminService
							.adminViewBookingsForDate(bookingDate);
					if(bookings.size()>0){
						displayBookings(bookings);
					}
					else{
						Client.printInfo("No bookings found!");
					}
				} catch (ConnectionException e) {
					Client.printError(e.getMessage());
				}
				break;

			case 5: // previous menu
				return;

			default:

				Client.printError("Please enter a valid option");
			}
		}
	}// end of method

	private void displayGuestList(HashMap<Booking, User> hashMap) {
		// TODO Auto-generated method stub

		String leftAlignFormat = "| %-7s | %-20s | %-7s | %-7s | %-11s | %-10s | %-10s | %-10s |%n";

		System.out
				.format("+---------+----------------------+---------+---------+-------------+------------+------------+------------+%n");
		System.out
				.format("| User ID | User Name            | Room No | Amount  | Booked From | Booked To  | Mobile     | Phone      |%n");
		System.out
				.format("+---------+----------------------+---------+---------+-------------+------------+------------+------------+%n");

		for (HashMap.Entry<Booking, User> entry : hashMap.entrySet()) {
			Booking booking = entry.getKey();
			User user = entry.getValue();

			System.out.format(leftAlignFormat, user.getUserId(),
					user.getUserName(), booking.getRoom().getRoomNo(),
					booking.getAmount(), booking.getBookedFrom(),
					booking.getBookedTo(), user.getMobileNo(), user.getPhone());
		}
		
		System.out
				.format("+---------+----------------------+---------+---------+-------------+------------+------------+------------+%n");

	}// end of method

	private void displayBookings(List<Booking> bookings) {
		// TODO Auto-generated method stub
		String leftAlignFormat = "| %-10s | %-7s | %-7s | %-20s | %-9s | %-9s | %-16d | %-18d |%n";

		
		System.out
				.format("+------------+---------+---------+----------------------+-------------+-----------+------------------+--------------------+%n");
		System.out
				.format("| Booking ID | Room ID | User ID | Hotel Name           | Booked From | Booked To | Number of Adults | Number of children |%n");
		System.out
				.format("+------------+---------+---------+----------------------+-------------+-----------+------------------+--------------------+%n");

		for (Booking booking : bookings) {
			System.out.format(leftAlignFormat, booking.getBookingId(), booking
					.getRoom().getRoomId(), booking.getUser().getUserId(),
					booking.getRoom().getHotel().getHotelName(), booking
							.getBookedFrom().toString(), booking.getBookedTo()
							.toString(), booking.getNoOfAdults(), booking
							.getNoOfChildren());
		}
		System.out
				.format("+------------+---------+---------+----------------------+-------------+-----------+------------------+--------------------+%n");

		
	}// end of method

	public void displayHotels(List<Hotel> hotels) {

		String leftAlignFormat = "| %-4s | %-10s | %-20s | %-25s | %-50s | %-22s | %-6d |%n";

		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+%n");
		System.out
				.format("| ID   | City       | Hotel Name           | Address                   | Description                                        | Average Rate per night | Rating |%n");
		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+%n");
		for (Hotel hotel : hotels) {
			System.out.format(leftAlignFormat, hotel.getHotelId(),
					hotel.getCity(), hotel.getHotelName(), hotel.getAddress(),
					hotel.getDescription(), new Double(hotel.getAvgRatePerNight()).toString(),
					hotel.getRating());
		}
		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+%n");
	}// end of method

} // end of class
