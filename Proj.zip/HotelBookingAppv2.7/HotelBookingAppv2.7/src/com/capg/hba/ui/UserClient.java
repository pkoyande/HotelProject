package com.capg.hba.ui;

import java.awt.BorderLayout;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.service.IUserService;
import com.capg.hba.service.UserServiceImpl;

public class UserClient {

	User user = null;
	static IUserService userService = new UserServiceImpl();

	public User userLogin() {
		int count = 0;
		

		Client.printHeading("USER LOGIN");
		System.out.println("Maximum 3 attempts allowed.");
		Client.printLineBreak();

		while (count < Client.ATTEMPTS) {

			count++;


			System.out.println("Enter Username:");

			String userName = Client.sc.next();

			System.out.println("Enter Password:");

			String password = Client.sc.next();

			try {
				user = userService.userSignIn(userName, password);
			} catch (ConnectionException e) {
				Client.printError(e.getMessage());
			}

			if (user == null) {

				Client.printError("The username or password you entered is incorrect!");
				continue;

			}// end of if

			else {

				break;

			}
		}// end of while count

		if (count >= Client.ATTEMPTS && user==null) {

			Client.printError("You have exceeded maximum number of attempts!");
			return null;
		}// end of if

		return user;

	}

	public void searchHotels() {

		Client.printHeading("SEARCH HOTELS");

		System.out.println("Enter City:");
		String city = Client.sc.next();
		String hotelId;
		String address = "";
		int rating = 0;
		double avgRate = 9999.99;

		int option1 = 0;
		int option2 = 0;

		Client.printHeading("FILTER YOUR SEARCH");
		
		loop1: while (true) {
			
			System.out.println();
			System.out.println("Select the filters to be applied-");
			System.out.println("1. Address");
			System.out.println("2. Average price per night");
			System.out.println("3. Minimum Rating");
			System.out.println("4. Show search results with current filters");
			System.out.println("5. Go to preious menu.\n");

			option1 = Client.inputOption();

			switch (option1) {

			case 1:

				System.out.println("Enter address:");
				Client.sc.nextLine();
				address = Client.sc.nextLine();
				break;

			case 2:

				System.out.println("Enter the Maximum rate per night:");
				avgRate = Client.sc.nextDouble();
				break;

			case 3:

				System.out.println("Enter the minimum rating:");
				rating = Client.sc.nextInt();
				break;

			case 4:

				HashMap<Hotel, Integer> hotels = null;
				try {
					hotels = userService.userSearchHotels(city, address,
							avgRate, rating);
				} catch (ConnectionException e) {
					Client.printError(e.getMessage());
				}

				if (hotels == null) {
					Client.printInfo("No Hotels retrieved.");
					
				} else {

					Client.printHeading("LIST OF HOTELS");

					displayHotels(hotels);

					Client.printHeading("DISPLAY ROOMS");
					
					loop2: while (true) {

						
						System.out
								.println("1. Display rooms for a particular hotel.");
						System.out.println("2. Go to previous menu.\n");

						option2 = Client.inputOption();

						switch (option2) {
						case 1:
							System.out
									.println("Enter hotel ID to display hotel rooms:");

							hotelId = Client.sc.next();

							List<Room> rooms = null;

							try {
								rooms = userService.userSearchRooms(hotelId);
							} catch (ConnectionException e) {
								e.printStackTrace();
								Client.printError(e.getMessage());
							}

							if (rooms != null) {
								Client.printHeading("LIST OF ROOMS");
								displayRooms(rooms);
								return;
							} else {
								System.out
										.println("There are no available rooms in chosen Hotel.");
							}

							continue loop2;

						case 2:
							continue loop1;

						default:
							Client.printError("Please enter a valid option!");
						}
					}
				}// end of else

			case 5:

				return;

			default:

				Client.printError("Please enter a valid option!");

			}// end of switch

		}// end of while
	}

	

	public void displayRooms(List<Room> rooms) {
		String leftAlignFormat = "| %-4s | %-7s | %-20s | %-14s |%n";
		System.out
				.format("+------+---------+----------------------+----------------+%n");
		System.out
				.format("| ID   | Room No | Room Type            | Rate per night |%n");
		System.out
				.format("+------+---------+----------------------+----------------+%n");
		for (Room room : rooms) {
			if (room.isAvailability()) {
				System.out.format(leftAlignFormat, room.getRoomId(),
						room.getRoomNo(), room.getRoomType(),
						new Double(room.getPerNightRate()).toString()); //made change here
			}
		}
		System.out
				.format("+------+---------+----------------------+----------------+%n");
	}

	public void userBookRoom(User user) {
		Booking booking = populateBooking(user); //made change here
		String bookingId = null;
		try {
			bookingId = userService.userBookRoom(booking);
			if (bookingId == null) {
				Client.printError("Booking Unsuccessful! Enter a valid room ID");
			} else {
				Client.printInfo("Booking Successful! Your booking Id is :"+bookingId);
			}
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}


	}

	public void viewBookingStatus() {
		Client.printHeading("VIEW BOOKING STATUS");
		String bookingId;
		Booking booking = null;
		System.out.println("Enter your booking ID:");
		bookingId = Client.sc.next();
		try {
			booking = userService.userBookingStatus(bookingId);
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}
		if (booking == null) {
			Client.printError("The booking Id is invalid!");
		} else {
			printBookingStatus(booking);
		}
	}

	private void printBookingStatus(Booking booking) {

		String leftAlignFormat = "| %-10s | %-7s | %-7s | %-20s | %-9s | %-9s | %-16d | %-18d |%n";

		System.out
				.format("+------------+---------+---------+----------------------+-------------+-----------+------------------+--------------------+%n");
		System.out
				.format("| Booking ID | Room ID | User ID | Hotel Name           | Booked From | Booked To | Number of Adults | Number of children |%n");
		System.out
				.format("+------------+---------+---------+----------------------+-------------+-----------+------------------+--------------------+%n");

		System.out.format(leftAlignFormat, booking.getBookingId(), booking
				.getRoom().getRoomId(), booking.getUser().getUserId(), booking
				.getRoom().getHotel().getHotelName(), booking.getBookedFrom()
				.toString(), booking.getBookedTo().toString(), booking
				.getNoOfAdults(), booking.getNoOfChildren());
		System.out
				.format("+------------+---------+---------+----------------------+-------------+-----------+------------------+--------------------+%n");
	}
	
	private Booking populateBooking(User user2) {
		Booking booking = new Booking();
		String roomId = null;
		int children = 0;
		Room room = null;
		int adults = 0;
		String to = null;
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		java.util.Date parsedFrom = null;
		java.util.Date parsedTo = null;
		
		
		Client.printHeading("BOOK HOTEL ROOM");
		loop: while (true) {
			System.out.println("Enter room Id:");
			roomId = Client.sc.next();

			try {
				room = userService.getRoom(roomId);
			} catch (ConnectionException e) {
				Client.printError(e.getMessage());
			}

			if (room != null && room.isAvailability()) {
				
				printRoomDetails(room);
				
				System.out.println("Do you want to book this room? 1.Yes 2.No");
				int option=Client.inputOption();
				
				if(option==1){
				while (true) {
					System.out.println("Enter the Number of adults:");

					adults = Client.sc.nextInt();
					if (!userService.validateNoOfAdults(adults)) {
						System.out.println("No of Adults can be maximum 10");
					} else
						break;
				}
				while (true) {
					System.out.println("Enter the number of children:");

					try{
					children = Client.sc.nextInt();
					}
					catch(InputMismatchException e){
						Client.printError("Number of digits should be in numbers. Please enter digits only!");
					}
					if (!userService.validateNoOfChildren(children)) {
						Client.printError("Number of Children can be maximum 4");
					} else
						break;
				}
				while (true) {

					while (true) {
						System.out.println("Enter the check-in date:");
						System.out.println("Date format is yyyy/MM/dd ");

						String from = Client.sc.next();
						try {

							if (userService.validateDate(from)) {
								parsedFrom = format.parse(from);
								break;
							} else
								System.out
										.println("Enter Date as per given Format yyyy/MM/dd");
						} catch (ParseException e2) {
							Client.printError("Enter a valid date!");
						}
					}
					while (true) {
						System.out.println("Enter the check-out date:");

						to = Client.sc.next();
						try {
							if (userService.validateDate(to)) {
								parsedTo = format.parse(to);
								break;
							} else
								System.out
										.println("Enter Date as per given Format yyyy/MM/dd");
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							Client.printError("Enter a valid date!");
						}
					}
					if (userService.validateBookingDates(parsedFrom, parsedTo)) {
						break;
					} else
						System.out
								.println("Check in Date should be before Check out Date");
				}
				Date bookingFrom = new java.sql.Date(parsedFrom.getTime());
				Date bookingTo = new java.sql.Date(parsedTo.getTime());

				booking = new Booking();
				booking.setUser(user);
				booking.setRoom(room);
				booking.setNoOfChildren(children);
				booking.setNoOfAdults(adults);
				booking.setBookedTo(bookingTo);
				booking.setBookedFrom(bookingFrom);
				
				break;
				}
				else{
					continue loop;
				}
			} else {
				Client.printError("Room Id doesnt exist or is invalid!!");
				Client.printError("Try Again!!");
			}
		}

		return booking;
	}
	
	private void printRoomDetails(Room room) {
		
		String leftAlignFormat = "| %-20s | %-25s | %-10s | %-7s | %-20s | %-14s |%n";
		System.out
				.format("+----------------------+---------------------------+------------+---------+----------------------+----------------+%n");
		System.out
				.format("| Hotel Name           | Address                   | City       | Room No | Room Type            | Rate per night |%n");
		System.out
				.format("+----------------------+---------------------------+------------+---------+----------------------+----------------+%n");
		System.out.format(leftAlignFormat, room.getHotel().getHotelName(), room
				.getHotel().getAddress(), room.getHotel().getCity(), room
				.getRoomNo(), room.getRoomType(), new Double(room.getPerNightRate()).toString());
		System.out
				.format("+----------------------+---------------------------+------------+---------+----------------------+----------------+%n");
		
		/*JFrame editorFrame = new JFrame("Image of room");
        editorFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        ImageIcon imageIcon = new ImageIcon(room.getPhoto());
        JLabel jLabel = new JLabel();
        jLabel.setIcon(imageIcon);
        editorFrame.getContentPane().add(jLabel, BorderLayout.CENTER);

        editorFrame.pack();
        editorFrame.setLocationRelativeTo(null);
        editorFrame.setVisible(true);
*/	}

	public static void displayHotels(HashMap<Hotel, Integer> hotels) {
		Hotel hotel;
		String leftAlignFormat = "| %-4s | %-10s | %-20s | %-25s | %-50s | %-22s | %-6d | %-15d |%n";

		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+-----------------+%n");
		System.out
				.format("| ID   | City       | Hotel Name           | Address                   | Description                                        | Average Rate per night | Rating | Rooms available |%n");
		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+-----------------+%n");
		for (HashMap.Entry<Hotel, Integer> entry : hotels.entrySet()) {
			hotel = entry.getKey();
			System.out.format(leftAlignFormat, hotel.getHotelId(),
					hotel.getCity(), hotel.getHotelName(), hotel.getAddress(),
					hotel.getDescription(), new Double(hotel.getAvgRatePerNight()).toString(),
					hotel.getRating(), entry.getValue());
		}
		System.out
				.format("+------+------------+----------------------+---------------------------+----------------------------------------------------+------------------------+--------+-----------------+%n");
	}

	public void register() {
		String userId = null;
		Client.printHeading("REGISTER USER");
		populateUser();
		try {
			userId = userService.userRegistration(user);
		} catch (ConnectionException e) {
			Client.printError(e.getMessage());
		}

		if (userId == null) {
			Client.printError("User registration failed. Try again!");
		} else {
			System.out
					.println("User registration successful. The user Id is: "
							+ userId);
		}
		
	}
	
	private void populateUser() {

		String userName;
		String password;
		String address;
		String mobile;
		String phone;
		String email;

		while (true) {
			System.out.println("Enter your Username:");
			userName = Client.sc.next();
			if (userService.validateUserName(userName)) {
				break;
			} else {
				Client.printError("Username should be of maximum 20 characters and should contain only alphabets");
			}
		}// end of while

		while (true) {
			System.out.println("Enter your Password:");
			password = Client.sc.next();
			if (userService.validatePassword(password)) {
				break;
			} else {
				Client.printError("Password should be of maximum 7 characters and should contain one capital letter, one digit and one special character.");
			}
		}// end of while

		while (true) {
			System.out.println("Enter your Address:");
			Client.sc.nextLine();
			address = Client.sc.nextLine();
			if (userService.validateUserAddress(address)) {
				break;
			} else {
				Client.printError("Address should be of maximum 25 characters.");
			}
		}// end of while

		while (true) {
			System.out.println("Enter you Mobile Number:");
			mobile = Client.sc.next();
			if (userService.validateMobile(mobile)) {
				break;
			} else {
				Client.printError("Mobile Number should consiste of 10 digits");
			}

		}// end of while

		while (true) {
			System.out.println("Enter your Phone Number:");
			phone = Client.sc.next();
			if (userService.validatePhone(phone)) {
				break;
			} else {
				Client.printError("Phone should consist of 8 digits.");
			}
		}// end of while

		while (true) {
			System.out.println("Enter you Email Id:");
			email = Client.sc.next();
			if (userService.validateEmail(email)) {
				break;
			} else {
				Client.printError("Invalid Email Id");
			}

		}// end of while

		user = new User();
		user.setUserName(userName);
		user.setPassword(password);
		user.setEmail(email);
		user.setMobileNo(mobile);
		user.setAddress(address);
		user.setPhone(phone);

	}// end of method


}// end of class
