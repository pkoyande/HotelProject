package com.capg.hba.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;

public interface IUserService {

	public String userRegistration(User user) throws ConnectionException;
	public User userSignIn(String userName,String password ) throws ConnectionException;
	public HashMap<Hotel,Integer> userSearchHotels(String city, String address, Double avgRate, int rating) throws ConnectionException;
	public List<Room> userSearchRooms(String hotelId) throws ConnectionException;
	public String userBookRoom(Booking booking) throws ConnectionException;
	public Booking userBookingStatus(String bookingId) throws ConnectionException;
	public boolean validateUser(User user);
	public boolean validateUserName(String userName);
	public boolean validatePassword(String password);
	public boolean validateRole(String role);
	public boolean validatePhone(String phoneNo);
	public boolean validateMobile(String mobileNo);
	public boolean validateEmail(String email);
	public boolean validateUserAddress(String userAddress);
	public boolean validateBookingDates(Date bookingFrom,Date bookingTo);
	public Room getRoom(String roomId) throws ConnectionException;
	public Hotel getHotel(String hotelId) throws ConnectionException;
	boolean validateDate(String date);
	boolean validateNoOfChildren(int children);
	boolean validateNoOfAdults(int adults);
	
}
