package com.capg.hba.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.bean.User;
import com.capg.hba.dao.BookingDAOImpl;
import com.capg.hba.dao.HotelDAOImpl;
import com.capg.hba.dao.IBookingDAO;
import com.capg.hba.dao.IHotelDAO;
import com.capg.hba.dao.IRoomDAO;
import com.capg.hba.dao.IUserDAO;
import com.capg.hba.dao.RoomDAOImpl;
import com.capg.hba.dao.UserDAOImpl;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.util.Util;

public class AdminServiceImpl implements IAdminService {
	  

	IHotelDAO hotelDao = new HotelDAOImpl();
	IRoomDAO roomDao = new RoomDAOImpl();
	IBookingDAO bookDao = new BookingDAOImpl();
	IUserDAO userDao = new UserDAOImpl();
	
	@Override
	public User adminLogin(String userName, String password)
			throws ConnectionException {

		return userDao.userSignIn(userName, password, "ADMIN");
	}

	@Override
	public String adminAddHotel(Hotel hotel) throws ConnectionException {

		return hotelDao.adminAddHotel(hotel);

	}

	@Override
	public boolean adminDeleteHotel(String hotelId) throws ConnectionException {

		return hotelDao.adminDeleteHotel(hotelId);

	}


	@Override
	public boolean adminModifyHotel(Hotel hotel) throws ConnectionException {
		return hotelDao.adminModifyHotel(hotel);

	}

	@Override
	public String adminAddRoom(Room room) throws ConnectionException {

		String result = null;
		if(validateRoom(room)){
			result = roomDao.adminAddRoom(room);
		}
		else{
			throw new ConnectionException("Room is invalid!");
		}
		return result;
	}

	@Override
	public boolean adminDeleteRoom(String roomId) throws ConnectionException {

		roomDao = new RoomDAOImpl();
		Room room = roomDao.getRoom(roomId);
		boolean result = false;
		if(room!=null){
			result = roomDao.adminDeleteRoom(roomId);
		}
		return result;
	}

	@Override
	public boolean adminModifyRoom(Room room) throws ConnectionException {

		if(validateRoom(room)){
			return roomDao.adminModifyRoom(room);
		}
		else{
			return false;
		}
	}

	@Override
	public List<Hotel> adminViewHotels() throws ConnectionException {

		return hotelDao.adminViewHotels();

	}
	
	@Override
	public List<Booking> adminViewBookingsForHotel(String hotelId)
			throws ConnectionException {

		return bookDao.adminViewBookingsForHotel(hotelId);

	}
	
	@Override
	public HashMap<Booking, User> adminViewGuestList(String hotelId)
			throws ConnectionException {
		HashMap<Booking, User> map = new HashMap<Booking, User>();
		List<Booking> book = bookDao.adminViewBookingsForHotel(hotelId);
		List<String> userid = new ArrayList<String>();
		List<User> users = new ArrayList<User>();
		for (Booking b : book) {
			userid.add(b.getUser().getUserId());
		}
		for (String u : userid) {
			users.add(userDao.getUser(u));
		}

		Iterator<Booking> i1 = book.iterator();
		Iterator<User> i2 = users.iterator();
		while (i1.hasNext() && i2.hasNext()) {
			map.put(i1.next(), i2.next());
		}

		return map;

	}
	
	@Override
	public List<Booking> adminViewBookingsForDate(Date date)
			throws ConnectionException {

		return bookDao.adminViewBookingsForDate(date);

	}


	@Override
	public boolean validateHotel(Hotel hotel) {
		return (validateCity(hotel.getCity())
				&& validateHotelName(hotel.getHotelName())
				&& validateAddress(hotel.getAddress())
				&& validateDescription(hotel.getDescription())
				&& validatePhoneNo(hotel.getPhoneNo1())
				&& validatePhoneNo(hotel.getPhoneNo2())
				&& validateRating(hotel.getRating())
				&& validateEmail(hotel.getEmail()) && validateFax(hotel
					.getFax()));
	}

	@Override
	public boolean validateCity(String city) {
		List<String> list = Util.citylist();
		if (list.contains(city.toLowerCase()))

			return true;
		else {
			
			return false;
		}
	}

	@Override
	public boolean validateHotelName(String hotelName) {
		if (hotelName.length() > 20) {
			
			return false;
		} else
			return true;
	}
	
	@Override
	public boolean validateAddress(String hotelAddress) {
		if (hotelAddress.length() > 20) {
			
			return false;
		} else
			return true;
	}

	@Override
	public boolean validateDescription(String Description) {
		if (Description.length() > 50) {
			return false;
		} else
			return true;
	}

	@Override
	public boolean validateRate(double Rate) {
		if (Rate > 0 && Rate < 9999.99) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validatePhoneNo(String phone) {
		if (phone.matches("(0/91)?[7-9][0-9]{9}")) {
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateFax(String fax) {
		if (fax.matches("[0-9]{5,10}")) {
			
			return true;

		} else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches("[A-Za-z]*@[A-Za-z]*.[A-Za-z]*"))
			return true;
		else {
			return false;
		}
	}
	
	@Override
	public boolean validateRoom(Room room) {
		return (validateRoomNo(room.getRoomNo()) && validateRoomType(room
				.getRoomType()));
	}

	@Override
	public boolean validateRoomNo(String roomNo) {
		int x = Integer.parseInt(roomNo);
		if (x > 99 && x < 999)
			return true;
		else {
			System.out
					.println("Invalid Room No!! Room No rane is between 100 to 999!!");
			return false;
		}
	}

	@Override
	public boolean validateRoomType(String roomType) {
		if (Util.roomList().contains(roomType))
			return true;
		else {
			return false;
		}
	}

	@Override
	public boolean validateRating(int x) {
		if (x > 0 && x < 6)
			return true;
		else {
			System.out.println("Invalid rating!! Rate on the scale of 5!!");
			System.out.println("% being the Highest");
			return false;
		}
	}

	@Override
	public Hotel getHotel(String hotelId) throws ConnectionException {

		return hotelDao.getHotel(hotelId);
	}
	
	@Override
	public Room getRoom(String roomId) throws ConnectionException {

		return roomDao.getRoom(roomId);
	}

}
