package com.capg.hba.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capg.hba.bean.Hotel;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.ui.Client;
import com.capg.hba.util.DBConnection;
import com.capg.hba.util.Util;


public class HotelDAOImpl implements IHotelDAO {

	
	//------------------------ 1. Hotel Booking Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	userSearchHotels(String city, String address, Double avgRate, int rating)
		 - Input Parameters	:	String city, String address, Double avgRate, int rating
		 - Return Type		:	List<Hotel>
		 - Throws			:  	ConnectionException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	17/9/2018
		 - Description		:	Search Specific Hotels depending on given Parameters
		 ********************************************************************************************************/
	@Override
	public List<Hotel> userSearchHotels(String city,
			String address, double avgRate, int rating) throws ConnectionException {
		
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<Hotel> hotelList=new ArrayList<Hotel>();
		
		try{
			
			ps=con.prepareStatement(QueryMapper.SEARCH_HOTEL_QUERY);
			ps.setString(1,city );
			ps.setString(2, "%"+address+"%");
			ps.setDouble(3, avgRate);
			ps.setInt(4, rating);
			resultset=ps.executeQuery();
			
			while(resultset.next()){
				
				Hotel hotel=new Hotel();
				hotel.setHotelId(resultset.getString("HOTEL_ID"));
				hotel.setCity(resultset.getString("CITY"));
				hotel.setAddress(resultset.getString("ADDRESS"));
				hotel.setHotelName(resultset.getString("HOTEL_NAME"));
				hotel.setDescription(resultset.getString("DESCRIPTION"));
				hotel.setAvgRatePerNight(resultset.getDouble("AVG_RATE_PER_NIGHT"));
				hotel.setPhoneNo1(resultset.getString("PHONE_NO1"));
				hotel.setPhoneNo2(resultset.getString("PHONE_NO2"));
				hotel.setRating(resultset.getInt("RATING"));
				hotel.setEmail(resultset.getString("EMAIL"));
				hotel.setFax(resultset.getString("FAX"));
				hotelList.add(hotel);
				
			}//end of while
			
			Client.logger.info("Hotel search successful with constraints: city="+city+" address= "+address+" avgrate<"+avgRate+" rating>"+rating);
			
		return hotelList;
		
		}//end of try
		
		catch(SQLException e){
			
			Client.logger.error("Exception in searching hotels with constraints: city="+city+" address= "+address+" avgrate<"+avgRate+" rating>"+rating+" "+e.getMessage());
			e.printStackTrace();
			throw new ConnectionException("Tehnical problem occured. Refer log");
			
		}//end of catch
		
		finally{
			
			try{
				
				resultset.close();
				ps.close();
				con.close();
			
			}//end of try 
			
			catch (SQLException e){
				
				Client.logger.error("Exception while closing db connection: "+e.getMessage());
				throw new ConnectionException("Error in closing db connection. Refer log.");

			}//end of catch
			
		}//end of finally block
		
	}//end of method

	//------------------------ 1. Hotel Booking Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	adminAddHotel(Hotel hotel)
		 - Input Parameters	:	Hotel hotel
		 - Return Type		:	int
		 - Throws			:  	ConnectionException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	17/9/2016
		 - Description		:	Adding Hotel
		 ********************************************************************************************************/
	
	@Override
	public String adminAddHotel(Hotel hotel) throws ConnectionException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		String hotelId=null;
		int id=0;
		int queryResult=0;
		
		try {
			
			while(true){
				
				id=Util.getRandomIntegerBetweenRange();
				
				hotelId= "H" + id ;
				preparedStatement=connection.prepareStatement(QueryMapper.RETREIVE_HOTELID_QUERY);
				preparedStatement.setString(1, hotelId);
				resultSet=preparedStatement.executeQuery();
	
				if(resultSet.next())
					continue;
				else
					break;
			
			}//end of while
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_HOTEL_QUERY);
			preparedStatement.setString(1,hotelId);
			preparedStatement.setString(2,hotel.getCity());			
			preparedStatement.setString(3,hotel.getHotelName());
			preparedStatement.setString(4,hotel.getAddress());
			preparedStatement.setString(5,hotel.getDescription());
			preparedStatement.setDouble(6,hotel.getAvgRatePerNight());
			preparedStatement.setString(7,hotel.getPhoneNo1());
			preparedStatement.setString(8,hotel.getPhoneNo2());
			preparedStatement.setInt(9,hotel.getRating());
			preparedStatement.setString(10,hotel.getEmail());
			preparedStatement.setString(11,hotel.getFax());
			
			queryResult=preparedStatement.executeUpdate();
			

			if(queryResult==0){
				
				Client.logger.error("Hotel Insertion failed.");
				throw new ConnectionException("Inserting hotel details failed!");

			}//end of if
			
			else{
				
				Client.logger.info("Hotel details added successfully Hotel Id: "+hotelId);
				return hotelId;
			
			}//end of else
		
		}//end of try
		
		catch (SQLException e) {
			
			Client.logger.error("Exception occured in hotel insertion: "+e.getMessage());
			throw new ConnectionException("Inserting hotel details failed. Refer log.");
			
		}//end of catch
		catch(NullPointerException e){
			Client.logger.error("Exception occured in hotel insertion: "+e.getMessage());
			throw new ConnectionException("Inserting hotel details failed. Refer log.");
		}
		
	}//end of method
	
	//------------------------ 1. Hotel Booking Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	adminDeleteHotel(Hotel hotel)
			 - Input Parameters	:	String hotelId
			 - Return Type		:	boolean
			 - Throws			:  	ConnectionException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	17/9/2018
			 - Description		:	Deleting Hotel
			 ********************************************************************************************************/
	
	@Override
	public boolean adminDeleteHotel(String hotelId) throws ConnectionException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		int queryResult=0;
		PreparedStatement preparedStatement=null;		
		
		try {
			
			preparedStatement=connection.prepareStatement(QueryMapper.DELETE_HOTEL_QUERY);
			preparedStatement.setString(1, hotelId);
			queryResult=preparedStatement.executeUpdate();
			
			if(queryResult==0){
				
				Client.logger.error("Deletion failed.");
				throw new ConnectionException("Deleting hotel details failed.");
				
			}//end of if
			
			else{
				
				Client.logger.info("Hotel details for Hotel Id "+hotelId+" deleted successfully.");
				return true;
				
			}//end of else
			
		}//end of try
		
		catch (SQLException e) {
			System.out.println("Raju");
			Client.logger.error("Exception occured while hotel deletion: "+e.getMessage());
			throw new ConnectionException("Technical problems occured. Refer log.");
			
		}//end of catch
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
	}//end of method

	//------------------------ 1. Hotel Booking Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	adminModifyHotel(Hotel hotel)
			 - Input Parameters	:	Hotel hotel
			 - Return Type		:	int
			 - Throws			:  	ConnectionException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	17/9/2018
			 - Description		:	Modifying Hotel
			 ********************************************************************************************************/
	@Override
	public boolean adminModifyHotel(Hotel hotel) throws ConnectionException {
		
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;	
		int queryResult=0;
		
		try {
				
			preparedStatement=connection.prepareStatement(QueryMapper.MODIFY_HOTEL_QUERY);
			
			preparedStatement.setString(1,hotel.getCity());			
			preparedStatement.setString(2,hotel.getHotelName());
			preparedStatement.setString(3,hotel.getAddress());
			preparedStatement.setString(4,hotel.getDescription());
			preparedStatement.setDouble(5,hotel.getAvgRatePerNight());
			preparedStatement.setString(6,hotel.getPhoneNo1());
			preparedStatement.setString(7,hotel.getPhoneNo2());
			preparedStatement.setInt(8,hotel.getRating());
			preparedStatement.setString(9,hotel.getEmail());
			preparedStatement.setString(10,hotel.getFax());
			preparedStatement.setString(11,hotel.getHotelId());
			
			queryResult=preparedStatement.executeUpdate();
			
			if(queryResult==0){
				
				Client.logger.error("Hotel Modification failed.");
				return false;
			}//end of if
			
			else{
				
				Client.logger.info("Hotel details modified successfully for Hotel Id: "+hotel.getHotelId());
				return true;
				
			}//end of else
			
		}//end of try
		
		catch (SQLException e) {
			
			Client.logger.error("Exception occured while hotel details of hotel = "+hotel+" :"+e.getMessage());
			throw new ConnectionException("Technical Problems occured. Refer log.");
			
		}//end of catch
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
		
		
	}//end of method

	//------------------------ 1. Hotel Booking Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	adminViewHotels()
			 - Input Parameters	:	
			 - Return Type		:	Array List of Hotels
			 - Throws			:  	ConnectionException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	17/9/2018
			 - Description		:	To View  Hotel List
			 ********************************************************************************************************/
	@Override
	public List<Hotel> adminViewHotels() throws ConnectionException {

		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<Hotel> hotelList=new ArrayList<Hotel>();
		
		try{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_HOTEL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next()){
				
				Hotel hotel=new Hotel();
				hotel.setHotelId(resultset.getString("HOTEL_ID"));
				hotel.setCity(resultset.getString("CITY"));
				hotel.setAddress(resultset.getString("ADDRESS"));
				hotel.setHotelName(resultset.getString("HOTEL_NAME"));
				hotel.setDescription(resultset.getString("DESCRIPTION"));
				hotel.setAvgRatePerNight(resultset.getDouble("AVG_RATE_PER_NIGHT"));
				hotel.setPhoneNo1(resultset.getString("PHONE_NO1"));
				hotel.setPhoneNo2(resultset.getString("PHONE_NO2"));
				hotel.setRating(resultset.getInt("RATING"));
				hotel.setEmail(resultset.getString("EMAIL"));
				hotel.setFax(resultset.getString("FAX"));
				hotelList.add(hotel);
				
			}//end of while
			
			Client.logger.info("List of all hotels retrieved successfully.");
			
			return hotelList;
		
		}//end of try
		
		catch(SQLException e){
			
			Client.logger.error("Exception while retrieving all  hotels: "+e.getMessage());
			throw new ConnectionException("Tehnical problem occured. Refer log");
			
		}//end of catch
		
		finally{
			
			try{
				
				resultset.close();
				ps.close();
				con.close();
				
			}//end of try 
			
			catch (SQLException e){
				
				Client.logger.error("Exception while closing db Connection: "+e.getMessage());
				throw new ConnectionException("Error in closing db connection");

			}//end of catch
			
		}//end of finally block
		
	}//end of method

	//------------------------ 1. Hotel Booking Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getHotel(String hotelId)
			 - Input Parameters	:	String hotelId
			 - Return Type		:	Hotel hotel
			 - Throws			:  	ConnectionException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	17/9/2018
			 - Description		:	Fetching Hotel Details as per given Hotel Id
			 ********************************************************************************************************/
	@Override
	public Hotel getHotel(String hotelId) throws ConnectionException {
		
		Hotel hotel=null; //made change here
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		try{
			
			ps=con.prepareStatement(QueryMapper.VIEW_HOTEL_QUERY);
			ps.setString(1, hotelId);
			resultset=ps.executeQuery();
			
			if(resultset.next()){
				
				hotel=new Hotel(); //made change here
				hotel.setHotelId(resultset.getString("HOTEL_ID"));
				hotel.setCity(resultset.getString("CITY"));
				hotel.setHotelName(resultset.getString("HOTEL_NAME"));
				hotel.setAddress(resultset.getString("ADDRESS")); //made change here
				hotel.setDescription(resultset.getString("DESCRIPTION"));
				hotel.setAvgRatePerNight(resultset.getDouble("AVG_RATE_PER_NIGHT"));
				hotel.setPhoneNo1(resultset.getString("PHONE_NO1"));
				hotel.setPhoneNo2(resultset.getString("PHONE_NO2"));
				hotel.setRating(resultset.getInt("RATING"));
				hotel.setEmail(resultset.getString("EMAIL"));
				hotel.setFax(resultset.getString("FAX"));
				
			}//end of if
			Client.logger.error("Details of hotel with Hotel Id "+hotelId+" retrieved successfully.");
			return hotel;
		
		}//end of try
		
		catch(Exception e){
			
			Client.logger.error("Exception while retrieving hotel for Hotel Id "+hotelId+" :"+e.getMessage());
			throw new ConnectionException("Technical problems occured. Refer log.");
			
		}//end of catch
		
		finally{
			
			try{
				
				resultset.close();
				ps.close();
				con.close();
				
			} //end of try
			
			catch (SQLException e){
				
				Client.logger.error("Exception in closing db connection : "+e.getMessage());
				throw new ConnectionException("Error in closing db connection.");

			}//end of catch
			
		}//end of finally block
		
	}//end of method

}//end of class
