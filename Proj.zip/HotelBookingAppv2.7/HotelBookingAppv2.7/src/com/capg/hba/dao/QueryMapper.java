package com.capg.hba.dao;

public interface QueryMapper {

	//Room details table query
	public static final String SEARCH_ROOMS = "Select * from roomdetails where hotel_id=?";
	public static final String ADD_ROOM = "Insert into roomdetails (room_id,hotel_id,room_no,room_type,per_night_rate,availability,photo_path)values (?,?,?,?,?,?,?)";
	public static final String GET_ROOM = "Select * from roomdetails where room_id=?";
	public static final String DELETE_ROOM = "Delete from roomdetails where room_id=?";
	public static final String MODIFY_ROOM = "Update roomdetails set hotel_id=?,room_no=?,room_type=?,per_night_rate=?,availability=?,photo_path=? where room_id=?";
	public static final String RETRIEVE_ROOMID_QUERY = "Select * from roomdetails where room_id=?";
	public static final String RETRIEVE_AVAILABILITY="Select availability from roomdetails where room_id=?";
	
	//Hotel table query
	public static final String RETRIVE_HOTEL_QUERY = "Select * from hotel where hotel_id=?";
	public static final String RETRIVE_ALL_HOTEL_QUERY = "SELECT * FROM hotel";
	public static final String VIEW_HOTEL_QUERY = "SELECT * FROM HOTEL  WHERE  hotel_id=?";
	public static final String INSERT_HOTEL_QUERY = "INSERT INTO hotel VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String DELETE_HOTEL_QUERY = "delete from hotel where hotel_id= ? ";
	public static final String MODIFY_HOTEL_QUERY = "update hotel set city=?,hotel_name=?,address=?,description=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? where hotel_id=?";
	public static final String RETREIVE_HOTELID_QUERY = "select * from hotel where hotel_id= ?";
	public static final String SEARCH_HOTEL_QUERY = "select * from hotel where city=? and address like ? and avg_rate_per_night<? and rating>?";
	
	//Booking table query
	public static final String RETREIVE_BOOKINGID_QUERY = "select * from bookingdetails where booking_id= ?";
	public static final String VIEW_BOOKING_QUERY = "select * from bookingdetails where booking_id=?";
	public static final String VIEW_BOOKING_FOR_HOTEL_QUERY = "select * from bookingdetails inner join roomdetails on bookingdetails.room_id=roomdetails.room_id  where roomdetails.hotel_id=?";
	public static final String VIEW_BOOKING_FOR_DATE_QUERY = "select * from bookingdetails where ? >=booked_from And ? <=booked_to";
	public static final String INSERT_BOOKING_QUERY = "INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";
	public static final String RETRIEVE_USERID_FROM_BOOKING = "select userid from bookingdetails where hotel_id=?";
	public static final String CHECK_DATES="select * from bookingdetails where (? between booked_from and booked_to or ? between booked_from and booked_to or (? <booked_from AND ? >booked_to)) AND room_id=?";
	
	//User table query
	public static final String  RETRIEVE_USERID_QUERY="SELECT * FROM USERS WHERE user_id=?";
	public static final String INSERT_USER_QUERY="INSERT INTO USERS VALUES(?,?,?,?,?,?,?,?)";
	public static final String RETRIEVE_USERNAME_PASSWORD_QUERY="SELECT * FROM USERS WHERE user_name=? AND password=? AND role=?";
	public static final String RETRIEVE_USER_QUERY="SELECT * FROM USERS WHERE user_id=?"; //made change here
}
