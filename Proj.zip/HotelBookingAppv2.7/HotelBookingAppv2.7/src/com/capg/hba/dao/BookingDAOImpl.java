package com.capg.hba.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Room;
import com.capg.hba.exceptions.ConnectionException;
import com.capg.hba.ui.Client;
import com.capg.hba.util.DBConnection;
import com.capg.hba.util.Util;

public class BookingDAOImpl implements IBookingDAO {
	
	
	//------------------------ 1. Hotel Booking Application --------------------------
	/*******************************************************************************************************
			 - Function Name	:	adminViewBookingsForHotel(String hotelId)
			 - Input Parameters	:	String hotelId
			 - Return Type		:	Array List of Booking booking
			 - Throws			:  	ConnectionException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	18/9/2018
			 - Description		:	Fetching Booking List for a specific hotel 
     ********************************************************************************************************/
	@Override
	public List<Booking> adminViewBookingsForHotel(String hotelId)
			throws ConnectionException {
		
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet resultset = null;
		List<Booking> bookingList = new ArrayList<Booking>();

		try {
			
			ps = con.prepareStatement(QueryMapper.VIEW_BOOKING_FOR_HOTEL_QUERY);
			ps.setString(1, hotelId);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				
				Booking book = new Booking();
				book.setBookingId(resultset.getString("BOOKING_ID"));
				book.setRoom(new RoomDAOImpl().getRoom(resultset.getString("ROOM_ID")));
				book.setUser(new UserDAOImpl().getUser(resultset.getString("USER_ID")));
				book.setBookedFrom(resultset.getDate("BOOKED_FROM"));
				book.setBookedTo(resultset.getDate("BOOKED_TO"));
				book.setNoOfAdults(resultset.getInt("NO_OF_ADULTS"));
				book.setNoOfChildren(resultset.getInt("NO_OF_CHILDREN"));
				book.setAmount(resultset.getDouble("AMOUNT"));
				bookingList.add(book);
				
			}// end of while
			
			Client.logger.info("Bookings for hotel "+hotelId+" retrieved successfully.");

			return bookingList;
			
		}// end of try
		
		catch (SQLException e) {
			
			Client.logger.error("Exception while retrieving bookings for hotel ID " + hotelId + ": " + e.getMessage());
			throw new ConnectionException(
					"Technical problem occured. Refer log.");
		
		}// end of catch
		
		finally {
			
			try {
				
				resultset.close();
				ps.close();
				con.close();
			}// end of try
				
			catch (SQLException e) {
				
				Client.logger.error("Exception in closing DB connection: " + e.getMessage());
				throw new ConnectionException("Error in closing db connection. Refer log.");

			}// end of catch
		
		}// end of finally block

	}// end of method

	
	//------------------------ 1. Hotel Booking Application --------------------------
	/*******************************************************************************************************
		 - Function Name	:	adminViewBookingsForDate(Date date)
		 - Input Parameters	:	Date date
		 - Return Type		:	Array List of Booking booking
		 - Throws			:  	ConnectionException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	18/9/2018
		 - Description		:	Fetching Booking List for a given Date
    ********************************************************************************************************/
	@Override
	public List<Booking> adminViewBookingsForDate(Date date)
			throws ConnectionException {

		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet resultset = null;
		List<Booking> bookingList = new ArrayList<Booking>();

		try {
			
			ps = con.prepareStatement(QueryMapper.VIEW_BOOKING_FOR_DATE_QUERY);
			ps.setDate(1, date);
			ps.setDate(2, date);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				
				Booking book = new Booking();
				book.setBookingId(resultset.getString("BOOKING_ID"));
				book.setRoom(new RoomDAOImpl().getRoom(resultset.getString("ROOM_ID")));
				book.setUser(new UserDAOImpl().getUser(resultset.getString("USER_ID")));
				book.setBookedFrom(resultset.getDate("BOOKED_FROM"));
				book.setBookedTo(resultset.getDate("BOOKED_TO"));
				book.setNoOfAdults(resultset.getInt("NO_OF_ADULTS"));
				book.setNoOfChildren(resultset.getInt("NO_OF_CHILDREN"));
				book.setAmount(resultset.getDouble("AMOUNT"));
				bookingList.add(book);
			
			}// end of while
			
			Client.logger.info("Bookings for date "+date+" retrieved successfully.");

			return bookingList;
		
		}// end of try
		
		catch (SQLException e) {
		
			Client.logger.error("Exception in retrieving bookings for date:" + date + ": " + e.getMessage());
			throw new ConnectionException("Tehnical problem occured. Refer log.");
		
		}// end of catch
		
		finally {
			
			try {
			
				resultset.close();
				ps.close();
				con.close();
			
			}// end of try
			
			catch (SQLException e) {
			
				Client.logger.error("Exception in closing DB connection: " + e.getMessage());
				throw new ConnectionException("Error in closing db connection. Refer log.");

			}// end of catch
		
		}// end of finally block
	
	}// end of method


	//------------------------ 1. Hotel Booking Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getBooking(String BookingId)
	 - Input Parameters	:	String BookingId
	 - Return Type		:	Booking booking
	 - Throws			:  	ConnectionException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/9/2018
	 - Description		:	Fetching Booking Details as per given Booking Id
	********************************************************************************************************/
	@Override
	public Booking getBooking(String BookingId) throws ConnectionException {

		Booking booking = null;
		Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet resultset = null;
	
		try {
		
			ps = con.prepareStatement(QueryMapper.VIEW_BOOKING_QUERY);
			ps.setString(1, BookingId);
			resultset = ps.executeQuery();

			if (resultset.next()) {
				
				booking = new Booking(); //made change here
				booking.setBookingId(resultset.getString("BOOKING_ID"));
				booking.setRoom(new RoomDAOImpl().getRoom(resultset
						.getString("ROOM_ID")));
				booking.setUser(new UserDAOImpl().getUser(resultset
						.getString("USER_ID")));
				booking.setBookedFrom(resultset.getDate("BOOKED_FROM"));
				booking.setBookedTo(resultset.getDate("BOOKED_TO"));
				booking.setNoOfAdults(resultset.getInt("NO_OF_ADULTS"));
				booking.setNoOfChildren(resultset.getInt("NO_OF_CHILDREN"));
				booking.setAmount(resultset.getDouble("AMOUNT"));
			
			}// end of if
			
			Client.logger.info("Details for booking "+BookingId+" retrieved successfully.");

		}// end of try
		
		catch (SQLException e) {
		
			Client.logger.error("Exception in retrieving booking for booking ID:" + BookingId + ": " + e.getMessage());
			throw new ConnectionException("Tehnical problem occured. Refer log.");
		
		}// end of catch
		
		finally {
			
			try {
				
				resultset.close();
				ps.close();
				con.close();
				
			}// end of try
				
			catch (SQLException e) {
				
				Client.logger.error("Exception in closing DB connection: " + e.getMessage());
				throw new ConnectionException("Error in closing db connection. Refer log.");

			}// end of catch
		
		}// end of finally block
		
		return booking;
	
	}// end of getBooking method
	
	
	//------------------------ 1. Hotel Booking Application --------------------------
	/*******************************************************************************************************
			 - Function Name	:	userAddBooking(Booking booking)
			 - Input Parameters	:	Booking booking
			 - Return Type		:	int
			 - Throws			:  	ConnectionException
			 - Author			:	CAPGEMINI
			 - Creation Date	:	18/9/2018
			 - Description		:	Adding Booking Details 
	********************************************************************************************************/
	@Override
	public String userAddBooking(Booking booking) throws ConnectionException {

		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement1 = null;
		PreparedStatement preparedStatement2 = null;
		ResultSet resultSet = null;
		String bookingId = null;
		int id = 0;
		int queryResult = 0;

		try {

			while (true) {
	
				id = Util.getRandomIntegerBetweenRange();

				bookingId = "B" + id;
				preparedStatement1 = connection
						.prepareStatement(QueryMapper.RETREIVE_BOOKINGID_QUERY);
				preparedStatement1.setString(1, bookingId);
				resultSet = preparedStatement1.executeQuery();

				if (resultSet.next())
					continue;
				else
					break;

			}// end of while

			preparedStatement2 = connection
					.prepareStatement(QueryMapper.INSERT_BOOKING_QUERY);
			preparedStatement2.setString(1, bookingId);
			preparedStatement2.setString(2, booking.getRoom().getRoomId());
			preparedStatement2.setString(3, booking.getUser().getUserId());
			preparedStatement2.setDate(4, booking.getBookedFrom());
			preparedStatement2.setDate(5, booking.getBookedTo());
			preparedStatement2.setDouble(6, booking.getNoOfAdults());
			preparedStatement2.setInt(7, booking.getNoOfChildren());
			preparedStatement2.setDouble(8, booking.getAmount());

			queryResult = preparedStatement2.executeUpdate();

			if (queryResult == 0) {
				Client.logger.error("Insertion failed! Booking: "+booking);
				throw new ConnectionException(
						"Inserting Booking details failed.");

			}// end of if
			
			else {
			
				Client.logger.info("Booking details added successfully. Booking ID: " + bookingId);
				return bookingId;
			
			}// end of else
		
		}// end of try
		
		catch (SQLException e) {
		
			Client.logger.error("Exception in adding booking for room Id " + booking.getRoom().getRoomId() + ": " + e.getMessage());
			throw new ConnectionException("Tehnical problem occured. Refer log.");
		
		}// end of catch
		
		finally {
			
			try {
				
				resultSet.close();
				preparedStatement1.close();
				preparedStatement2.close();
				connection.close();
				
			}// end of try
				
			catch (SQLException e) {
				
				Client.logger.error("Exception in closing DB connection: " + e.getMessage());
				throw new ConnectionException("Error in closing db connection. Refer log.");

			}// end of catch
		
		}// end of finally blocks
	
	}// end of Method


	@Override
	public boolean checkBookingDates(Date from, Date to, Room room) throws ConnectionException {
		
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.CHECK_DATES);
			preparedStatement.setDate(1, from);
			preparedStatement.setDate(2, to);
			preparedStatement.setDate(3, from);
			preparedStatement.setDate(4, to);
			preparedStatement.setString(5, room.getRoomId());
			rs=preparedStatement.executeQuery();
			if(!rs.next())
			{
				return true;
			}
				else
				{
					//System.out.println("Mila kuch");
					return false;
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				connection.close();
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return false;
	}
	
}
