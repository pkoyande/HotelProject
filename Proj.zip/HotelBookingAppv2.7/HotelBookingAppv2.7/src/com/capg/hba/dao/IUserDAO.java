package com.capg.hba.dao;

import com.capg.hba.bean.User;
import com.capg.hba.exceptions.ConnectionException;

public interface IUserDAO {

	//Dealing with User Table
	public String addUser(User user) throws ConnectionException;
	public User userSignIn(String userName,String password, String role) throws ConnectionException;
	public User getUser(String userId) throws ConnectionException;
}
