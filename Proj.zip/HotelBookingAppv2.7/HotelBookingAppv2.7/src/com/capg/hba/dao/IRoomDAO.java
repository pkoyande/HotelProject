package com.capg.hba.dao;

import java.util.List;
import java.util.Map;

import com.capg.hba.bean.Hotel;
import com.capg.hba.bean.Room;
import com.capg.hba.exceptions.ConnectionException;

public interface IRoomDAO {
	
	//dealing with Room Table
	public List<Room> userSearchRooms(String hotelId) throws ConnectionException;
	public String adminAddRoom(Room room) throws ConnectionException;
	public boolean adminDeleteRoom(String roomId) throws ConnectionException;
	public boolean adminModifyRoom(Room room) throws ConnectionException;
	public Room getRoom(String roomId) throws ConnectionException;
	public Map<Hotel,Integer> userHotelRooms(List<Hotel> hotels);
	public boolean getAvailabilityOfRoom(String roomId) throws ConnectionException;
}
