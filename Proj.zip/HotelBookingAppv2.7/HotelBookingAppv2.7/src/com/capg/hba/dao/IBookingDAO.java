package com.capg.hba.dao;


import java.sql.Date;
import java.util.List;

import com.capg.hba.bean.Booking;
import com.capg.hba.bean.Room;
import com.capg.hba.exceptions.ConnectionException;

public interface IBookingDAO {
//DONE
	public List<Booking> adminViewBookingsForHotel(String hotelId) throws ConnectionException;
	public List<Booking> adminViewBookingsForDate(Date date) throws ConnectionException;
	public Booking getBooking(String BookingId) throws ConnectionException;
	String userAddBooking(Booking booking) throws ConnectionException;
	public boolean checkBookingDates(java.sql.Date bookedFrom,
			java.sql.Date bookedTo, Room room) throws ConnectionException;
	
}
